// WARDROBE ITEMS: every garment and accessory the app can dress a person in. Each one is a small recipe (shape + details), drawn
// from the person's body measurements (wardrobe-core.js), so the same recipe fits every character style and every uploaded character.
// Colours, fabric patterns and second colours are free, so one recipe is hundreds of different pieces (see VARIANTS in wardrobe-catalog.js).

import { halfW, hemY, shade, mix, lum } from './wardrobe-core.js';

export const GARMENTS = new Map();
export const SLOTS = ['top', 'bottom', 'outer', 'dress', 'feet', 'head', 'eyes', 'face', 'neck', 'waist', 'bag', 'back', 'ears', 'jewel', 'tail'];

/** Registers an item. o: { cat, aka[], col[] (default colours), pat (allowed patterns: true | false), nat (hints for the built-in styles), draw } */
function def(id, slot, o) {
  GARMENTS.set(id, { id, slot, cat: o.cat || slot, aka: o.aka || [], col: o.col || ['#3b4a7a'], pat: o.pat !== false && ['top', 'bottom', 'outer', 'dress'].includes(slot), nat: o.nat || {}, draw: o.draw });
}
const L = (a) => a; // readability: a list of names

// ------------------------------------------------------------------ torso geometry shared by tops, coats and dresses
function torso(K, a, o) {
  const B = K.B, k = K.k, Y = B.Y;
  const y0 = Y.sh - 3 * k;
  const yh = typeof o.hem === 'string' ? hemY(B, o.hem) : hemY(B, o.hem == null ? 'bottom' : o.hem);
  const fit = (o.fit || 0) * k + (o.grow || 0), fl = (o.flare || 0);
  const nw = B.neck.w + 5 * k;
  const w = (y) => halfW(B, y, fit + (y > Y.hip ? (y - Y.hip) * fl : 0));
  const ys = [y0 + 14 * k, Y.chest, Y.waist, Math.min(yh, Y.hip + 4), yh].filter((v, i, arr) => v <= yh && (i === 0 || v > arr[i - 1] + 2));
  const wsh = w(y0 + 6 * k) + (o.shoulder || 0) * k;
  const nk = o.neck || 'crew';
  const d = { crew: 14, scoop: 30, v: 36, deepv: 56, boat: 5, square: 22, polo: 10, collar: 8, turtle: 6, henley: 12, cowl: 20, halter: 44, strapless: 0, mandarin: 5, hood: 12, none: 2, open: 8 }[nk] ?? 14;
  const dk = d * k;
  const wh = w(yh);
  const left = ys.slice(1).slice(0, -1).reverse().map((y) => `L${-w(y)},${y}`).join('');
  const rightPts = ys.slice(1).map((y) => `L${w(y)},${y}`).join('');
  const nec = nk === 'strapless' ? `Q0,${y0 + 8 * k} ${wsh * 0.9},${y0 + 3 * k}`
    : (nk === 'v' || nk === 'deepv') ? `L${-nw},${y0} L0,${y0 + dk} L${nw},${y0} L${wsh * 0.9},${y0 + 3 * k}`
      : nk === 'square' ? `L${-nw},${y0} L${-nw},${y0 + dk} L${nw},${y0 + dk} L${nw},${y0} L${wsh * 0.9},${y0 + 3 * k}`
        : `L${-nw},${y0} Q0,${y0 + dk * 1.6} ${nw},${y0} L${wsh * 0.9},${y0 + 3 * k}`;
  const D = `M${-wsh * 0.9},${y0 + 3 * k}${nec}Q${wsh},${y0 + 6 * k} ${wsh},${y0 + 20 * k}${rightPts}Q0,${yh + (o.sag || 3) * k} ${-wh},${yh}${left}L${-wsh},${y0 + 20 * k}Q${-wsh},${y0 + 6 * k} ${-wsh * 0.9},${y0 + 3 * k}Z`;
  return { D, y0, yh, w, wsh, nw, nk, dk, wh };
}

/** The standard top / coat / dress body: shape, neckline, collar and the chosen details. */
function makeTop(o) {
  return (K, a) => {
    const B = K.B, k = K.k, back = a.view === 'back';
    const T = torso(K, a, { ...o, neck: back ? (o.neck === 'turtle' || o.neck === 'hood' || o.neck === 'collar' || o.neck === 'polo' ? o.neck : 'crew') : o.neck });
    const col = a.col, fill = K.cloth(col, a.pat, a.col2), dk = K.dk(col), lt = K.lt(col);
    let s = '', front = '', backL = '';
    if (o.open && !back) {
      // open jacket / cardigan: the inner shirt shows down the middle
      const inner = a.col2 && !a.pat ? a.col2 : (lum(col) > 0.5 ? '#f1efe8' : '#e9e6df');
      s += `<path d="${T.D}" ${K.st(inner)}/>`;
      const half = (sg) => `M${sg * T.nw * 1.1},${T.y0} L${sg * T.wsh * 0.9},${T.y0 + 3 * k} Q${sg * T.wsh},${T.y0 + 6 * k} ${sg * T.wsh},${T.y0 + 20 * k} L${sg * T.w(T.yh)},${T.yh} L${sg * (T.nw * 0.55 + (o.gap || 8) * k)},${T.yh} L${sg * (T.nw * 0.9)},${T.y0 + 30 * k}Z`;
      s += `<path d="${half(-1)}" ${K.st(fill)}/><path d="${half(1)}" ${K.st(fill)}/>`;
      s += K.shadeOver(half(-1)) + K.shadeOver(half(1));
    } else {
      s += `<path d="${T.D}" ${K.st(fill)}/>` + K.shadeOver(T.D);
    }
    const mid = (y) => y;
    const y0 = T.y0, yh = T.yh, nw = T.nw, wsh = T.wsh;
    const det = o.det || [];
    // shoulder caps and short sleeves: small cloth caps at the shoulders so the garment reads even where the arm is the character's own
    const sl = o.sleeve || 'short';
    const cap = (sg, len) => `<path d="M${sg * (wsh - 4)},${y0 + 2 * k} Q${sg * (wsh + 16 * k)},${y0 + 4 * k} ${sg * (wsh + len * 0.55)},${y0 + len * 0.7} L${sg * (wsh + len * 0.15)},${y0 + len * 1.05} L${sg * (wsh - 6)},${y0 + 22 * k}Z" ${K.st(fill)}/>`;
    if (!back || true) {
      const len = { none: 0, cap: 14 * k, short: 30 * k, three: 46 * k, long: 52 * k }[sl] || 0;
      if (len && !K.B.custom) s += cap(-1, len) + cap(1, len);
    }
    if (nk0(o) === 'hood') {
      const hy = y0 - 8 * k;
      backL += `<path d="M${-wsh * 0.78},${hy + 10 * k} Q${-wsh * 0.9},${hy - 34 * k} 0,${hy - 38 * k} Q${wsh * 0.9},${hy - 34 * k} ${wsh * 0.78},${hy + 10 * k} Q0,${hy + 24 * k} ${-wsh * 0.78},${hy + 10 * k}Z" ${K.st(dk)}/>`;
      if (!back) s += `<path d="M${-nw - 6 * k},${y0 - 2 * k} Q0,${y0 + 28 * k} ${nw + 6 * k},${y0 - 2 * k}" ${K.ln(1.1)}/>` + `<path d="M${-nw * 0.55},${y0 + 14 * k} v${22 * k} M${nw * 0.55},${y0 + 14 * k} v${22 * k}" fill="none" stroke="${lum(col) > 0.6 ? '#444' : '#eee'}" stroke-width="${3 * k}" stroke-linecap="round"/>`;
    }
    if (o.neck === 'turtle' || o.neck === 'mandarin') {
      const th = (o.neck === 'turtle' ? 26 : 12) * k, tw = B.neck.w + 5 * k;
      s += `<rect x="${-tw}" y="${y0 - th}" width="${tw * 2}" height="${th + 2}" rx="${6 * k}" ${K.st(fill)}/><path d="M${-tw + 3},${y0 - th * 0.55} H${tw - 3}" ${K.ln(0.7)}/>`;
    }
    if (o.neck === 'collar' || o.neck === 'polo' || det.includes('collarShirt')) {
      const cw = (o.neck === 'polo' ? 20 : 26) * k;
      if (!back) {
        s += `<path d="M${-nw},${y0 - 4 * k} L${-nw - cw * 0.9},${y0 + cw * 0.35} L${-nw * 0.1},${y0 + cw * 1.15} L0,${y0 + 3 * k}Z" ${K.st(lt)}/><path d="M${nw},${y0 - 4 * k} L${nw + cw * 0.9},${y0 + cw * 0.35} L${nw * 0.1},${y0 + cw * 1.15} L0,${y0 + 3 * k}Z" ${K.st(lt)}/>`;
      } else s += `<path d="M${-nw - 4},${y0 - 3 * k} Q0,${y0 + 8 * k} ${nw + 4},${y0 - 3 * k} L${nw + 4},${y0 + 3 * k} Q0,${y0 + 14 * k} ${-nw - 4},${y0 + 3 * k}Z" ${K.st(lt)}/>`;
    }
    if (o.neck === 'cowl') s += `<path d="M${-nw - 6},${y0 - 2 * k} Q0,${y0 + 34 * k} ${nw + 6},${y0 - 2 * k}" ${K.ln(1)}/><path d="M${-nw - 3},${y0 + 8 * k} Q0,${y0 + 42 * k} ${nw + 3},${y0 + 8 * k}" ${K.ln(0.7)}/>`;
    if (back) {
      const btxt = det.includes('number') ? `<text x="0" y="${y0 + (yh - y0) * 0.5}" text-anchor="middle" font-size="${46 * k}" font-weight="800" font-family="Arial,sans-serif" fill="#fff" stroke="#222" stroke-width="${1.4}">${(a.item && a.item.num) || 7}</text>` : '';
      return { back: backL, mid: s + (det.includes('zip') || det.includes('buttons') ? `<path d="M0,${y0 + 4 * k} V${yh}" ${K.ln(0.5)}/>` : '') + btxt, front: '' };
    }
    const cx = o.open ? (o.gap || 8) * k : 0;
    for (const t of det) {
      if (t === 'buttons') { const n = Math.max(3, Math.round((yh - y0) / (34 * k))); for (let i = 0; i < n; i++) { const y = y0 + 30 * k + i * ((yh - y0 - 40 * k) / Math.max(1, n - 1)); s += `<circle cx="${cx}" cy="${y.toFixed(1)}" r="${2.4 * k + 0.8}" fill="${lt}" stroke="${K.F.ink}" stroke-width="${Math.max(0.8, K.F.sw * 0.3)}"/>`; } s += `<path d="M${cx},${y0 + 24 * k} V${yh}" ${K.ln(0.45)}/>`; }
      else if (t === 'zip') s += `<path d="M${cx},${y0 + 6 * k} V${yh}" ${K.ln(0.9)}/><rect x="${cx - 2.4}" y="${y0 + 6 * k}" width="4.8" height="${8 * k}" rx="1.4" fill="#c9ccd3" stroke="${K.F.ink}" stroke-width="${Math.max(0.7, K.F.sw * 0.25)}"/>`;
      else if (t === 'pocket') { const px = T.w(Y(B).chest) * 0.5; s += `<path d="M${px - 14 * k},${y0 + 40 * k} h${26 * k} v${24 * k} h${-26 * k}z" ${K.ln(0.6)}/>`; }
      else if (t === 'pockets') { const yy = hemY(B, 'waist') + 6 * k; for (const sg of [-1, 1]) s += `<path d="M${sg * (T.w(yy) * 0.7) - 15 * k},${yy} h${30 * k} v${(yh - yy) * 0.7} h${-30 * k}z" ${K.ln(0.55)}/>`; }
      else if (t === 'kangaroo') s += `<path d="M${-T.w(yh) * 0.7},${yh - (yh - y0) * 0.34} H${T.w(yh) * 0.7} L${T.w(yh) * 0.78},${yh} H${-T.w(yh) * 0.78}Z" ${K.ln(0.7)}/><path d="M${-T.w(yh) * 0.3},${yh - (yh - y0) * 0.3} L${-T.w(yh) * 0.38},${yh - 4} M${T.w(yh) * 0.3},${yh - (yh - y0) * 0.3} L${T.w(yh) * 0.38},${yh - 4}" ${K.ln(0.5)}/>`;
      else if (t === 'hemband') s += `<path d="M${-T.wh},${yh - 9 * k} H${T.wh}" ${K.ln(0.7)}/><path d="M${-T.wh},${yh - 9 * k} H${T.wh} L${T.wh},${yh} H${-T.wh}Z" fill="${dk}" opacity=".35"/>`;
      else if (t === 'stripeH') { for (let i = 1; i <= 3; i++) { const y = y0 + (yh - y0) * (0.25 + i * 0.17); s += `<rect x="${-T.w(y)}" y="${y}" width="${T.w(y) * 2}" height="${7 * k}" fill="${a.col2 || lt}" opacity=".9"/>`; } }
      else if (t === 'chestband') { const y = y0 + (yh - y0) * 0.3; s += `<rect x="${-T.w(y)}" y="${y}" width="${T.w(y) * 2}" height="${9 * k}" fill="${a.col2 || lt}"/>`; }
      else if (t === 'lapel') s += `<path d="M${-nw},${y0} L${-nw - 22 * k},${y0 + 32 * k} L${-6 * k},${y0 + 70 * k} L0,${y0 + 40 * k}Z" ${K.st(K.lt(col))}/><path d="M${nw},${y0} L${nw + 22 * k},${y0 + 32 * k} L${6 * k},${y0 + 70 * k} L0,${y0 + 40 * k}Z" ${K.st(K.lt(col))}/>`;
      else if (t === 'tieIn') s += `<path d="M0,${y0 + 4 * k} L${-9 * k},${y0 + 14 * k} L0,${y0 + 24 * k} L${9 * k},${y0 + 14 * k}Z" ${K.st(a.col2 || '#b02a37')}/><path d="M0,${y0 + 22 * k} L${-8 * k},${y0 + 74 * k} L0,${y0 + 86 * k} L${8 * k},${y0 + 74 * k}Z" ${K.st(a.col2 || '#b02a37')}/>`;
      else if (t === 'belt') { const y = hemY(B, 'waist'); s += `<rect x="${-T.w(y) - 1}" y="${y - 6 * k}" width="${T.w(y) * 2 + 2}" height="${12 * k}" ${K.st('#3a2a1c')}/><rect x="${-8 * k}" y="${y - 7 * k}" width="${16 * k}" height="${14 * k}" rx="2" ${K.st('#d4af37', 0.7)}/>`; }
      else if (t === 'epaulette') for (const sg of [-1, 1]) s += `<rect x="${sg * wsh - 12 * k + (sg > 0 ? -2 : 2)}" y="${y0 + 2 * k}" width="${24 * k}" height="${9 * k}" rx="2" ${K.st('#d4af37', 0.7)}/>`;
      else if (t === 'logo') s += `<circle cx="${-T.w(y0 + 50 * k) * 0.45}" cy="${y0 + 50 * k}" r="${9 * k}" ${K.st(a.col2 || '#fff', 0.6)}/><path d="M${-T.w(y0 + 50 * k) * 0.45 - 4 * k},${y0 + 50 * k} l${4 * k},${4 * k} l${6 * k},${-8 * k}" ${K.ln(0.6)}/>`;
      else if (t === 'cross') s += `<rect x="${-4 * k}" y="${y0 + 34 * k}" width="${8 * k}" height="${24 * k}" fill="#d32f2f"/><rect x="${-12 * k}" y="${y0 + 42 * k}" width="${24 * k}" height="${8 * k}" fill="#d32f2f"/>`;
      else if (t === 'number') s += `<text x="0" y="${y0 + (yh - y0) * 0.62}" text-anchor="middle" font-size="${48 * k}" font-weight="800" font-family="Arial,sans-serif" fill="#fff" stroke="#222" stroke-width="1.4">${(a.item && a.item.num) || 7}</text>`;
      else if (t === 'ruffle') { let r = ''; for (let i = -4; i <= 4; i++) r += `<circle cx="${i * 9 * k}" cy="${y0 + 12 * k}" r="${6 * k}" ${K.st(lt, 0.6)}/>`; s += r; }
      else if (t === 'bow') s += `<path d="M0,${y0 + 6 * k} l${-16 * k},${-8 * k} v${16 * k}z M0,${y0 + 6 * k} l${16 * k},${-8 * k} v${16 * k}z" ${K.st(lt, 0.8)}/><circle cx="0" cy="${y0 + 6 * k}" r="${3.4 * k}" ${K.st(dk, 0.7)}/>`;
      else if (t === 'drawstring') s += `<path d="M${-9 * k},${y0 + 24 * k} v${30 * k} M${9 * k},${y0 + 24 * k} v${30 * k}" fill="none" stroke="#eee" stroke-width="${2.6 * k}" stroke-linecap="round"/>`;
      else if (t === 'wrap') s += `<path d="M${-T.w(yh)},${yh} L${nw * 0.6},${y0 + 8 * k}" ${K.ln(0.9)}/><path d="M${T.w(yh) * 0.2},${yh} L${-nw * 0.6},${y0 + 8 * k}" ${K.ln(0.6)}/>`;
      else if (t === 'collarCoat') s += `<path d="M${-nw},${y0 - 6 * k} L${-nw - 30 * k},${y0 + 24 * k} L${-8 * k},${y0 + 56 * k}Z" ${K.st(dk)}/><path d="M${nw},${y0 - 6 * k} L${nw + 30 * k},${y0 + 24 * k} L${8 * k},${y0 + 56 * k}Z" ${K.st(dk)}/>`;
      else if (t === 'fur') s += `<path d="M${-wsh},${y0 + 6 * k} Q0,${y0 + 40 * k} ${wsh},${y0 + 6 * k} L${wsh},${y0 + 22 * k} Q0,${y0 + 56 * k} ${-wsh},${y0 + 22 * k}Z" fill="#f4f1ea" stroke="${K.F.ink}" stroke-width="${K.F.sw * 0.6}"/>`;
      else if (t === 'sash') s += `<path d="M${-wsh * 0.9},${y0 + 8 * k} L${wsh * 0.9},${yh - 4 * k}" stroke="${a.col2 || '#d4af37'}" stroke-width="${12 * k}" stroke-linecap="butt" opacity=".95"/>`;
      else if (t === 'apronBib') s += `<path d="M${-T.w(y0 + 60 * k) * 0.62},${y0 + 24 * k} H${T.w(y0 + 60 * k) * 0.62} L${T.w(yh) * 0.82},${yh} H${-T.w(yh) * 0.82}Z" ${K.st(a.col2 || '#f4f4f0')}/>`;
    }
    return { back: backL, mid: s, front };
  };
}
const nk0 = (o) => o.neck;
const Y = (B) => B.Y;

// ------------------------------------------------------------------ TOPS (and coats): [id, aliases, recipe, built-in hints, default colours]
// hints: s = the stickman's own top, h = the lifelike person's own outfit, arm = 'skin' (short sleeves) or 'cloth' (long sleeves) for the default character
function T(id, aka, o, nat, col, cat = 'top', slot = 'top') {
  def(id, slot, { cat, aka, col, nat, draw: makeTop(o) });
}
const SS = { s: 'tshirt', h: 'tshirt', arm: 'skin' }, LS = { s: 'sweater', h: 'sweater', arm: 'cloth' };
T('tshirt', L(['t-shirt', 'tee', 'shirt short sleeve']), { sleeve: 'short', det: [] }, SS, ['#3b6fd6']);
T('vneck', L(['v-neck', 'v neck tee']), { neck: 'v', sleeve: 'short' }, SS, ['#e0e0e0']);
T('croptee', L(['crop top', 'crop tee', 'cropped tee']), { hem: 'crop', sleeve: 'short', fit: -2 }, SS, ['#f08fb0']);
T('longtee', L(['longline tee', 'long tee', 'oversized tee', 'big tee']), { hem: 'thigh', sleeve: 'short', fit: 8 }, SS, ['#333a46']);
T('pockettee', L(['pocket tee']), { sleeve: 'short', det: ['pocket'] }, SS, ['#c19a6b']);
T('graphictee', L(['graphic tee', 'print tee', 'logo tee']), { sleeve: 'short', det: ['logo'] }, SS, ['#1c1c20']);
T('ringer', L(['ringer tee', 'baseball tee', 'raglan']), { sleeve: 'short', det: ['chestband'] }, SS, ['#f5f5f2']);
T('henley', L(['henley', 'grandad shirt']), { neck: 'henley', sleeve: 'long', det: ['buttons'] }, LS, ['#8a8f98']);
T('polo', L(['polo', 'polo shirt', 'golf shirt']), { neck: 'polo', sleeve: 'short', det: ['buttons'] }, { s: 'tshirt', h: 'polo', arm: 'skin' }, ['#2f6fd6']);
T('longpolo', L(['long sleeve polo']), { neck: 'polo', sleeve: 'long', det: ['buttons'] }, { s: 'sweater', h: 'polo', arm: 'cloth' }, ['#1b2a5a']);
T('tank', L(['tank top', 'vest top', 'singlet', 'sleeveless', 'sleeveless top', 'muscle tank']), { sleeve: 'none', neck: 'scoop' }, { s: 'tank', h: 'tshirt', arm: 'skin' }, ['#f5f5f2']);
T('camisole', L(['cami', 'camisole', 'spaghetti strap']), { sleeve: 'none', neck: 'v', fit: -4, hem: 'belly' }, { s: 'tank', h: 'tshirt', arm: 'skin' }, ['#f3b8c4']);
T('tube', L(['tube top', 'bandeau', 'strapless top']), { sleeve: 'none', neck: 'strapless', hem: 'belly', fit: -3 }, { s: 'tank', h: 'tshirt', arm: 'skin' }, ['#d32f2f']);
T('halter', L(['halter top', 'halterneck']), { sleeve: 'none', neck: 'halter', hem: 'belly' }, { s: 'tank', h: 'tshirt', arm: 'skin' }, ['#7b3fa8']);
T('bodysuit', L(['bodysuit', 'leotard']), { sleeve: 'long', hem: 'bottom', fit: -5, neck: 'scoop' }, LS, ['#1c1c20']);
T('longsleeve', L(['long sleeve', 'long sleeve tee', 'thermal', 'base layer']), { sleeve: 'long', det: [] }, LS, ['#5a6577']);
T('sweater', L(['sweater', 'jumper', 'pullover', 'knit', 'knitwear']), { sleeve: 'long', fit: 6, det: ['hemband'] }, LS, ['#b5502a'], 'top');
T('vsweater', L(['v-neck sweater', 'sweater vest long']), { neck: 'v', sleeve: 'long', fit: 6, det: ['hemband'] }, LS, ['#1b2a5a']);
T('turtleneck', L(['turtleneck', 'polo neck', 'roll neck', 'rollneck']), { neck: 'turtle', sleeve: 'long', fit: 2 }, { s: 'sweater', h: 'turtleneck', arm: 'cloth' }, ['#1c1c20']);
T('cowlsweater', L(['cowl neck', 'cowl sweater']), { neck: 'cowl', sleeve: 'long', fit: 6 }, LS, ['#c8a6dc']);
T('hoodie', L(['hoodie', 'hooded sweatshirt', 'pullover hoodie']), { neck: 'hood', sleeve: 'long', fit: 8, hem: 'bottom', det: ['kangaroo', 'drawstring', 'hemband'] }, { s: 'hoodie', h: 'hoodie', arm: 'cloth' }, ['#5a6577']);
T('ziphoodie', L(['zip hoodie', 'zip-up hoodie', 'zip up']), { neck: 'hood', sleeve: 'long', fit: 8, det: ['zip', 'pockets', 'hemband'] }, { s: 'hoodie', h: 'hoodie', arm: 'cloth' }, ['#1b2a5a']);
T('crophoodie', L(['crop hoodie', 'cropped hoodie']), { neck: 'hood', sleeve: 'long', hem: 'crop', fit: 6, det: ['drawstring'] }, { s: 'hoodie', h: 'hoodie', arm: 'cloth' }, ['#f08fb0']);
T('sweatshirt', L(['sweatshirt', 'crewneck sweatshirt', 'crewneck']), { sleeve: 'long', fit: 8, det: ['hemband', 'logo'] }, { s: 'sweater', h: 'sweater', arm: 'cloth' }, ['#8a8f98']);
T('fleece', L(['fleece', 'fleece jacket']), { neck: 'mandarin', sleeve: 'long', fit: 8, det: ['zip', 'pockets'] }, { s: 'jacket', h: 'jacket', arm: 'cloth' }, ['#2f5f3a']);
T('cardigan', L(['cardigan', 'cardi', 'knit cardigan']), { open: true, sleeve: 'long', fit: 6, hem: 'thigh', det: ['buttons'], gap: 4 }, { s: 'sweater', h: 'cardigan', arm: 'cloth' }, ['#9bb59a']);
T('opencardigan', L(['open cardigan', 'long cardigan', 'duster']), { open: true, sleeve: 'long', fit: 6, hem: 'knee', gap: 12 }, { s: 'sweater', h: 'cardigan', arm: 'cloth' }, ['#b08aa8']);
T('shirt', L(['shirt', 'button-up', 'button up', 'button down', 'dress shirt', 'oxford', 'oxford shirt', 'work shirt']), { neck: 'collar', sleeve: 'long', det: ['buttons'] }, { s: 'jacket', h: 'shirt', arm: 'cloth' }, ['#f5f5f2']);
T('shortshirt', L(['short sleeve shirt', 'short-sleeve shirt', 'camp shirt']), { neck: 'collar', sleeve: 'short', det: ['buttons', 'pocket'] }, { s: 'tshirt', h: 'shirt', arm: 'skin' }, ['#7cc4ee']);
T('flannel', L(['flannel', 'flannel shirt', 'lumberjack shirt', 'plaid shirt']), { neck: 'collar', sleeve: 'long', fit: 4, det: ['buttons', 'pocket'], hem: 'bottom' }, { s: 'jacket', h: 'shirt', arm: 'cloth' }, ['#c8302a'], 'top');
T('hawaiian', L(['hawaiian shirt', 'aloha shirt', 'tropical shirt']), { neck: 'collar', sleeve: 'short', fit: 4, det: ['buttons'] }, { s: 'tshirt', h: 'shirt', arm: 'skin' }, ['#2fc4c0']);
T('blouse', L(['blouse', 'dressy top', 'work blouse']), { neck: 'v', sleeve: 'long', fit: 2, det: [] }, { s: 'jacket', h: 'blouse', arm: 'cloth' }, ['#f3b8c4']);
T('bowblouse', L(['bow blouse', 'pussy bow blouse']), { neck: 'crew', sleeve: 'long', det: ['bow'] }, { s: 'jacket', h: 'blouse', arm: 'cloth' }, ['#f3ecd8']);
T('ruffleblouse', L(['ruffle blouse', 'frilly top']), { neck: 'crew', sleeve: 'short', det: ['ruffle'] }, { s: 'tshirt', h: 'blouse', arm: 'skin' }, ['#ffbc96']);
T('peasant', L(['peasant blouse', 'boho top', 'off shoulder top', 'off-shoulder']), { neck: 'boat', sleeve: 'three', fit: 6 }, { s: 'tshirt', h: 'blouse', arm: 'skin' }, ['#f3ecd8']);
T('wraptop', L(['wrap top', 'wrap blouse']), { neck: 'v', sleeve: 'three', det: ['wrap'] }, { s: 'jacket', h: 'blouse', arm: 'cloth' }, ['#8a4fd6']);
T('tunic', L(['tunic', 'long top', 'kurta', 'kurti']), { neck: 'mandarin', sleeve: 'long', hem: 'thigh', fit: 4, det: ['buttons'] }, { s: 'sweater', h: 'shirt', arm: 'cloth' }, ['#f7c52b']);
T('dashiki', L(['dashiki', 'african top', 'ankara top', 'ankara shirt']), { neck: 'v', sleeve: 'short', fit: 8, hem: 'hip' }, { s: 'tshirt', h: 'shirt', arm: 'skin' }, ['#c8302a']);
T('jersey', L(['jersey', 'sports jersey', 'football jersey', 'soccer jersey', 'team shirt', 'basketball jersey']), { neck: 'v', sleeve: 'short', fit: 4, det: ['number', 'chestband'] }, { s: 'tshirt', h: 'polo', arm: 'skin' }, ['#d32f2f']);
T('basketballjersey', L(['basketball vest', 'sleeveless jersey']), { neck: 'scoop', sleeve: 'none', fit: 6, det: ['number'] }, { s: 'tank', h: 'tshirt', arm: 'skin' }, ['#f2a516']);
T('rugby', L(['rugby shirt', 'rugby jersey']), { neck: 'collar', sleeve: 'long', fit: 3, det: ['stripeH'] }, { s: 'sweater', h: 'polo', arm: 'cloth' }, ['#1f4fb0']);
T('scrubs', L(['scrubs', 'scrub top', 'nurse top', 'medical scrubs', 'surgical scrubs']), { neck: 'v', sleeve: 'short', fit: 3, det: ['pocket'] }, { s: 'tshirt', h: 'shirt', arm: 'skin' }, ['#1b8a8a']);
T('chefjacket', L(['chef jacket', 'chef coat', 'chefs jacket', 'cook jacket']), { neck: 'mandarin', sleeve: 'long', fit: 4, det: ['buttons'], hem: 'hip' }, { s: 'jacket', h: 'coat', arm: 'cloth' }, ['#f5f5f2']);
T('labcoat', L(['lab coat', 'doctor coat', 'white coat', 'doctors coat', 'scientist coat']), { neck: 'collar', sleeve: 'long', fit: 6, hem: 'thigh', open: false, det: ['buttons', 'pocket'] }, { s: 'jacket', h: 'coat', arm: 'cloth' }, ['#f5f5f2'], 'outer', 'outer');
T('karategi', L(['karate gi', 'gi', 'judo gi', 'martial arts uniform', 'taekwondo dobok', 'dobok']), { neck: 'v', sleeve: 'three', fit: 8, hem: 'thigh', det: ['wrap', 'belt'] }, { s: 'jacket', h: 'shirt', arm: 'cloth' }, ['#f5f5f2']);
T('kimono', L(['kimono', 'yukata', 'hanbok top']), { neck: 'v', sleeve: 'long', fit: 10, hem: 'midi', det: ['wrap', 'sash'] }, { s: 'jacket', h: 'dress', arm: 'cloth' }, ['#c2307e'], 'dress', 'dress');
T('robe', L(['robe', 'bathrobe', 'dressing gown', 'housecoat']), { neck: 'v', sleeve: 'long', fit: 12, hem: 'shin', det: ['wrap', 'belt'] }, { s: 'jacket', h: 'coat', arm: 'cloth' }, ['#f3ecd8'], 'dress', 'dress');
T('pajamas', L(['pajamas', 'pyjamas', 'pjs', 'sleepwear', 'nightshirt']), { neck: 'collar', sleeve: 'long', fit: 6, det: ['buttons', 'pocket'] }, { s: 'jacket', h: 'shirt', arm: 'cloth' }, ['#7cc4ee']);
// ---- vests / waistcoats
T('vest', L(['vest', 'waistcoat', 'gilet', 'suit vest']), { neck: 'v', sleeve: 'none', fit: -2, det: ['buttons'], hem: 'bottom' }, { s: 'tank', h: 'vest', arm: 'skin' }, ['#363a42'], 'top', 'outer');
T('puffervest', L(['puffer vest', 'padded vest', 'body warmer', 'bodywarmer']), { neck: 'mandarin', sleeve: 'none', fit: 8, det: ['zip'] }, { s: 'tank', h: 'vest', arm: 'skin' }, ['#1f5f3a'], 'top', 'outer');
T('hivis', L(['hi-vis vest', 'safety vest', 'high vis', 'reflective vest', 'construction vest']), { neck: 'v', sleeve: 'none', fit: 4, det: ['zip', 'stripeH'] }, { s: 'tank', h: 'vest', arm: 'skin' }, ['#f57c20'], 'top', 'outer');
T('lifejacket', L(['life jacket', 'life vest', 'flotation vest']), { neck: 'crew', sleeve: 'none', fit: 12, det: ['zip', 'chestband'] }, { s: 'tank', h: 'vest', arm: 'skin' }, ['#f57c20'], 'top', 'outer');
T('apron', L(['apron', 'kitchen apron', 'cooking apron', 'barista apron', 'butcher apron']), { neck: 'none', sleeve: 'none', fit: -8, hem: 'thigh', det: ['apronBib'] }, { s: 'tank', h: 'vest', arm: 'skin' }, ['#f5f5f2'], 'outer', 'outer');
T('overallsbib', L(['dungarees', 'overall top', 'bib overalls', 'overalls']), { neck: 'square', sleeve: 'none', fit: -4, hem: 'bottom', det: ['pocket'] }, { s: 'tank', h: 'denim', arm: 'skin' }, ['#3f5f8f'], 'top', 'outer');
// ---- jackets and coats
T('jacket', L(['jacket', 'casual jacket', 'coat short', 'zip jacket']), { neck: 'mandarin', open: false, sleeve: 'long', fit: 6, det: ['zip', 'pockets'] }, { s: 'jacket', h: 'jacket', arm: 'cloth' }, ['#3b4a7a'], 'outer', 'outer');
T('bomber', L(['bomber', 'bomber jacket', 'flight jacket', 'varsity jacket', 'letterman jacket', 'windbreaker']), { neck: 'mandarin', sleeve: 'long', fit: 8, hem: 'bottom', det: ['zip', 'hemband'] }, { s: 'jacket', h: 'bomber', arm: 'cloth' }, ['#2f5f3a'], 'outer', 'outer');
T('trackjacket', L(['track jacket', 'tracksuit top', 'sports jacket', 'warm up jacket']), { neck: 'mandarin', sleeve: 'long', fit: 6, det: ['zip', 'chestband'] }, { s: 'jacket', h: 'bomber', arm: 'cloth' }, ['#1f4fb0'], 'outer', 'outer');
T('denimjacket', L(['denim jacket', 'jean jacket']), { neck: 'collar', sleeve: 'long', fit: 6, hem: 'bottom', det: ['buttons', 'pocket'] }, { s: 'jacket', h: 'denim', arm: 'cloth' }, ['#3f5f8f'], 'outer', 'outer');
T('leather', L(['leather jacket', 'biker jacket', 'moto jacket']), { neck: 'collar', open: false, sleeve: 'long', fit: 4, hem: 'bottom', det: ['zip', 'lapel'] }, { s: 'jacket', h: 'leather', arm: 'cloth' }, ['#1c1c20'], 'outer', 'outer');
T('blazer', L(['blazer', 'sport coat', 'sports jacket', 'smart jacket', 'suit jacket']), { neck: 'v', open: true, sleeve: 'long', fit: 3, hem: 'thigh', det: ['lapel', 'buttons'], gap: 6 }, { s: 'jacket', h: 'blazer', arm: 'cloth' }, ['#363a42'], 'outer', 'outer');
T('suitjacket', L(['suit', 'business suit', 'tuxedo', 'tux', 'formal suit', 'dinner jacket']), { neck: 'v', open: true, sleeve: 'long', fit: 3, hem: 'thigh', det: ['lapel', 'tieIn', 'buttons'], gap: 6 }, { s: 'jacket', h: 'suit', arm: 'cloth' }, ['#1b2a5a'], 'outer', 'outer');
T('puffer', L(['puffer jacket', 'puffer', 'padded jacket', 'down jacket', 'winter jacket', 'ski jacket']), { neck: 'turtle', sleeve: 'long', fit: 14, hem: 'bottom', det: ['zip', 'hemband'] }, { s: 'jacket', h: 'jacket', arm: 'cloth' }, ['#d32f2f'], 'outer', 'outer');
T('parka', L(['parka', 'hooded coat', 'winter coat', 'anorak']), { neck: 'hood', sleeve: 'long', fit: 12, hem: 'thigh', det: ['zip', 'pockets', 'fur'] }, { s: 'hoodie', h: 'coat', arm: 'cloth' }, ['#5a6b3a'], 'outer', 'outer');
T('trench', L(['trench coat', 'trench', 'mac', 'mackintosh', 'detective coat']), { neck: 'collar', sleeve: 'long', fit: 6, hem: 'knee', det: ['buttons', 'belt', 'collarCoat'], open: false }, { s: 'jacket', h: 'coat', arm: 'cloth' }, ['#c19a5b'], 'outer', 'outer');
T('overcoat', L(['overcoat', 'long coat', 'wool coat', 'topcoat', 'peacoat', 'pea coat']), { neck: 'v', open: false, sleeve: 'long', fit: 7, hem: 'knee', det: ['collarCoat', 'buttons'] }, { s: 'jacket', h: 'coat', arm: 'cloth' }, ['#4a4f5a'], 'outer', 'outer');
T('raincoat', L(['raincoat', 'rain jacket', 'slicker', 'rain mac', 'poncho raincoat']), { neck: 'hood', sleeve: 'long', fit: 10, hem: 'thigh', det: ['zip', 'pockets'] }, { s: 'hoodie', h: 'coat', arm: 'cloth' }, ['#f7c52b'], 'outer', 'outer');
T('poncho', L(['poncho', 'cape top']), { neck: 'v', sleeve: 'none', fit: 20, hem: 'thigh', shoulder: 18 }, { s: 'jacket', h: 'coat', arm: 'cloth' }, ['#c8643d'], 'outer', 'outer');
T('uniformjacket', L(['uniform jacket', 'military jacket', 'army jacket', 'officer jacket', 'dress uniform', 'captain jacket']), { neck: 'mandarin', sleeve: 'long', fit: 4, hem: 'bottom', det: ['buttons', 'epaulette', 'belt'] }, { s: 'jacket', h: 'blazer', arm: 'cloth' }, ['#2f5f3a'], 'outer', 'outer');
T('policeshirt', L(['police shirt', 'police uniform', 'cop shirt', 'security shirt', 'guard shirt']), { neck: 'collar', sleeve: 'short', det: ['buttons', 'epaulette', 'pocket'] }, { s: 'jacket', h: 'shirt', arm: 'skin' }, ['#1b2a5a']);
T('pilotshirt', L(['pilot shirt', 'pilot uniform', 'airline uniform', 'captain shirt']), { neck: 'collar', sleeve: 'long', det: ['buttons', 'epaulette', 'tieIn'] }, { s: 'jacket', h: 'shirt', arm: 'cloth' }, ['#f5f5f2']);
T('schoolblazer', L(['school blazer', 'school uniform', 'school jacket']), { neck: 'v', open: true, sleeve: 'long', hem: 'bottom', det: ['lapel', 'tieIn', 'logo'], gap: 6 }, { s: 'jacket', h: 'blazer', arm: 'cloth' }, ['#1b2a5a'], 'outer', 'outer');
T('cape', L(['cape coat', 'shawl jacket']), { neck: 'collar', sleeve: 'none', fit: 16, hem: 'hip', shoulder: 14, det: ['buttons'] }, { s: 'jacket', h: 'coat', arm: 'cloth' }, ['#7a1a2a'], 'outer', 'outer');

// ------------------------------------------------------------------ BOTTOMS, SKIRTS, DRESSES
const NATIVE_LEGS = new Set(['stickman', 'human']); // these styles draw trousers and shorts themselves (they swing with the legs); the others get cloth tubes
function legTubes(K, a, o) {
  const B = K.B, k = K.k, Y = B.Y;
  const yb = Y.hip - 2 * k, ye = hemY(B, o.hem || 'ankle');
  const fill = K.cloth(a.col, a.pat, a.col2);
  const lx = B.legs.x, lw = B.legs.w / 2 + (o.wide || 0) * k + 2;
  let s = '';
  for (const sg of [-1, 1]) {
    const x0 = sg * lx, wTop = lw + 5 * k, wBot = lw + (o.wide || 0) * k * 0.6 + (o.flare || 0) * k;
    const d = `M${x0 - wTop},${yb} L${x0 + wTop},${yb} L${x0 + wBot},${ye} L${x0 - wBot},${ye}Z`;
    s += `<path d="${d}" ${K.st(fill)}/>` + K.shadeOver(d);
    if (o.cuff) s += `<path d="M${x0 - wBot},${ye - 7 * k} H${x0 + wBot}" ${K.ln(0.6)}/>`;
  }
  return s;
}
function waistBand(K, a, o) {
  const B = K.B, k = K.k, y = hemY(B, o.rise || 'waist'), w = halfW(B, y, 1 * k);
  const col = a.col2 && !a.pat ? a.col2 : K.dk(a.col);
  let s = `<rect x="${-w}" y="${y - 3 * k}" width="${w * 2}" height="${(o.band || 9) * k}" ${K.st(o.beltCol || col, 0.8)}/>`;
  if (o.det && o.det.includes('belt')) s += `<rect x="${-7 * k}" y="${y - 3 * k}" width="${14 * k}" height="${(o.band || 9) * k}" rx="2" ${K.st('#d4af37', 0.6)}/>`;
  return s;
}
function makeBottom(o) {
  return (K, a) => {
    const B = K.B, k = K.k;
    let mid = '';
    const native = NATIVE_LEGS.has(B.style) && !o.skirt;
    if (o.skirt) {
      const yw = hemY(B, o.rise || 'waist'), yh = hemY(B, o.hem || 'knee');
      const w0 = halfW(B, yw, 1 * k), w1 = halfW(B, B.Y.hip) + (o.flare == null ? 14 : o.flare) * k + (yh - B.Y.hip) * (o.spread || 0.12);
      const fill = K.cloth(a.col, a.pat, a.col2);
      const wv = o.pleats ? 5 : 0;
      const d = `M${-w0},${yw} L${w0},${yw} Q${w1 * 0.9},${(yw + yh) / 2} ${w1},${yh} ${wv ? `Q${w1 * 0.5},${yh + 6 * k} 0,${yh - 2 * k} Q${-w1 * 0.5},${yh + 6 * k}` : `Q0,${yh + 6 * k}`} ${-w1},${yh} Q${-w1 * 0.9},${(yw + yh) / 2} ${-w0},${yw}Z`;
      mid += `<path d="${d}" ${K.st(fill)}/>` + K.shadeOver(d);
      if (o.pleats) for (let i = -3; i <= 3; i++) mid += `<path d="M${i * w0 / 3.4},${yw + 4 * k} L${i * w1 / 3.2},${yh}" ${K.ln(0.35)} opacity=".7"/>`;
      if (o.tiers) for (let t = 1; t <= o.tiers; t++) { const y = lerp2(yw, yh, t / (o.tiers + 1)); mid += `<path d="M${-w1 * (0.5 + 0.4 * t / o.tiers)},${y} Q0,${y + 8 * k} ${w1 * (0.5 + 0.4 * t / o.tiers)},${y}" ${K.ln(0.5)}/>`; }
      if (o.layers) for (let t = 1; t <= 3; t++) mid += `<path d="M${-w1},${yh - t * 9 * k} Q0,${yh - t * 9 * k + 10 * k} ${w1},${yh - t * 9 * k}" ${K.ln(0.45)} opacity=".6"/>`;
      if (o.wrap) mid += `<path d="M${w0 * 0.6},${yw} L${-w1 * 0.4},${yh}" ${K.ln(0.7)}/>`;
      mid += waistBand(K, a, { ...o, band: 8 });
    } else {
      if (!native) mid += legTubes(K, a, o);
      // the hip part of trousers: a cloth belt line, pockets and the like, over the body
      const yb = hemY(B, o.rise || 'waist'), yh = hemY(B, 'bottom');
      const fill = K.cloth(a.col, a.pat, a.col2);
      const w = halfW(B, yh, 1 * k);
      if (native || true) { const d = `M${-halfW(B, yb, 1 * k)},${yb} L${halfW(B, yb, 1 * k)},${yb} L${w},${yh} L${-w},${yh}Z`; mid += `<path d="${d}" ${K.st(fill)}/>` + K.shadeOver(d); }
      if (o.det && o.det.includes('fly')) mid += `<path d="M0,${yb} V${yb + 30 * k}" ${K.ln(0.5)}/>`;
      if (o.det && o.det.includes('pockets')) for (const sg of [-1, 1]) mid += `<path d="M${sg * w * 0.9},${yb + 4 * k} Q${sg * w * 0.5},${yb + 14 * k} ${sg * w * 0.45},${yb + 26 * k}" ${K.ln(0.5)}/>`;
      if (o.det && o.det.includes('cargo')) for (const sg of [-1, 1]) mid += `<rect x="${sg * w * 0.62 - 9 * k}" y="${yh - 2 * k}" width="${18 * k}" height="${16 * k}" ${K.ln(0.5)}/>`;
      if (o.det && o.det.includes('stripe')) for (const sg of [-1, 1]) mid += `<path d="M${sg * w * 0.9},${yb + 6 * k} L${sg * w * 0.9},${yh}" stroke="${a.col2 || '#fff'}" stroke-width="${4 * k}"/>`;
      mid += waistBand(K, a, o);
      if (!native && o.hem === 'ankle' && !K.B.custom && B.style === 'doodle') { /* thin legs: nothing more */ }
    }
    return { mid };
  };
}
const lerp2 = (a, b, t) => a + (b - a) * t;
function BT(id, aka, o, nat, col) { def(id, 'bottom', { cat: 'bottom', aka, col, nat, draw: makeBottom(o) }); }
// nat: p = the stickman's trousers, h = the lifelike person's bottom, long = trousers (true) or shorts (false)
const PANTS = { p: 'jeans', h: 'pants', long: true }, SHORTS = { p: 'straight-shorts', h: 'shorts', long: false };
BT('jeans', L(['jeans', 'blue jeans', 'denim', 'denim pants', 'trousers jeans']), { hem: 'ankle', det: ['pockets', 'fly'], cuff: true }, PANTS, ['#3f5f8f']);
BT('skinnyjeans', L(['skinny jeans', 'slim jeans', 'slim fit']), { hem: 'ankle', det: ['pockets', 'fly'], wide: -3 }, PANTS, ['#1b2a5a']);
BT('widejeans', L(['wide jeans', 'baggy jeans', 'baggy pants', 'baggy trousers', 'loose jeans']), { hem: 'ankle', det: ['pockets'], wide: 9 }, { p: 'joggers', h: 'wide', long: true }, ['#5a6577']);
BT('pants', L(['pants', 'trousers', 'slacks', 'dress pants', 'formal trousers', 'office trousers']), { hem: 'ankle', det: ['fly', 'belt'], rise: 'waist' }, PANTS, ['#363a42']);
BT('chinos', L(['chinos', 'khakis', 'khaki pants']), { hem: 'ankle', det: ['pockets', 'fly', 'belt'], cuff: true }, PANTS, ['#c19a6b']);
BT('cargo', L(['cargo pants', 'cargo trousers', 'combat pants', 'work pants']), { hem: 'ankle', det: ['cargo', 'pockets'], wide: 4 }, { p: 'joggers', h: 'cargo', long: true }, ['#7a8a2a']);
BT('joggers', L(['joggers', 'sweatpants', 'track pants', 'trackpants', 'sweats', 'tracksuit bottoms']), { hem: 'ankle', det: ['stripe'], wide: 2, cuff: true }, { p: 'joggers', h: 'pants', long: true }, ['#5a6577']);
BT('leggings', L(['leggings', 'tights', 'yoga pants', 'gym leggings', 'jeggings']), { hem: 'ankle', wide: -4 }, { p: 'jeans', h: 'pants', long: true }, ['#1c1c20']);
BT('slacksflare', L(['flared trousers', 'bell bottoms', 'flares', 'bootcut']), { hem: 'ankle', flare: 10, wide: 2 }, PANTS, ['#8a4fd6']);
BT('palazzo', L(['palazzo pants', 'harem pants', 'culottes', 'wide leg pants', 'wide-leg']), { hem: 'ankle', wide: 12, flare: 8 }, { p: 'joggers', h: 'wide', long: true }, ['#2fc4c0']);
BT('overallpants', L(['overall pants', 'workman trousers', 'boiler suit bottoms']), { hem: 'ankle', det: ['pockets', 'cargo'], wide: 3 }, PANTS, ['#3f5f8f']);
BT('shorts', L(['shorts', 'casual shorts', 'chino shorts']), { hem: 'thigh', det: ['pockets'] }, SHORTS, ['#c19a6b']);
BT('denimshorts', L(['denim shorts', 'jean shorts', 'cutoffs', 'cut offs']), { hem: 'mini', det: ['pockets'] }, SHORTS, ['#3f5f8f']);
BT('bermuda', L(['bermuda shorts', 'bermudas', 'knee shorts', 'long shorts', 'capri', 'capris', 'cropped trousers']), { hem: 'knee', det: ['pockets', 'cargo'], wide: 2 }, SHORTS, ['#7a8a2a']);
BT('gymshorts', L(['gym shorts', 'running shorts', 'sports shorts', 'athletic shorts', 'basketball shorts', 'football shorts', 'soccer shorts']), { hem: 'thigh', det: ['stripe'], wide: 3 }, SHORTS, ['#1f4fb0']);
BT('swimtrunks', L(['swim trunks', 'swimming trunks', 'board shorts', 'boardshorts', 'swim shorts', 'swimsuit bottom']), { hem: 'thigh', det: ['stripe'] }, SHORTS, ['#27b8e0']);
BT('bikeshorts', L(['bike shorts', 'cycling shorts', 'compression shorts']), { hem: 'mini', wide: -3 }, SHORTS, ['#1c1c20']);
BT('hotpants', L(['hot pants', 'short shorts', 'booty shorts']), { hem: 'bottom', wide: -2 }, SHORTS, ['#f08fb0']);
// ---- skirts
function SK(id, aka, o, nat, col) { def(id, 'bottom', { cat: 'skirt', aka, col, nat, draw: makeBottom({ skirt: true, ...o }) }); }
const SKN = { p: 'skirt', h: 'skirt-midi', long: true, skirt: true };
SK('miniskirt', L(['mini skirt', 'miniskirt', 'short skirt']), { hem: 'mini', flare: 8 }, { ...SKN, h: 'skirt-mini' }, ['#d63aa0']);
SK('skirt', L(['skirt', 'a-line skirt', 'aline skirt', 'knee skirt', 'school skirt']), { hem: 'knee', flare: 12 }, { ...SKN, h: 'skirt-midi' }, ['#1b2a5a']);
SK('pleated', L(['pleated skirt', 'tennis skirt', 'cheer skirt']), { hem: 'thigh', flare: 14, pleats: true }, { ...SKN, h: 'skirt-mini' }, ['#7a1a2a']);
SK('midiskirt', L(['midi skirt', 'calf skirt', 'tea length skirt']), { hem: 'midi', flare: 14 }, SKN, ['#9bb59a']);
SK('maxiskirt', L(['maxi skirt', 'long skirt', 'floor skirt', 'full skirt']), { hem: 'ankle', flare: 20, spread: 0.1 }, { ...SKN, h: 'skirt-long' }, ['#7b3fa8']);
SK('pencilskirt', L(['pencil skirt', 'office skirt', 'tight skirt']), { hem: 'knee', flare: 0, spread: 0 }, { ...SKN, h: 'skirt-midi' }, ['#363a42']);
SK('denimskirt', L(['denim skirt', 'jean skirt']), { hem: 'mini', flare: 6 }, { ...SKN, h: 'skirt-mini' }, ['#3f5f8f']);
SK('tutu', L(['tutu', 'ballet skirt', 'ballerina skirt', 'tulle skirt']), { hem: 'mini', flare: 34, layers: true }, { ...SKN, h: 'skirt-mini' }, ['#f3b8c4']);
SK('kilt', L(['kilt', 'scottish kilt', 'tartan skirt']), { hem: 'knee', flare: 8, pleats: true }, { ...SKN, h: 'skirt-midi' }, ['#7a1a2a']);
SK('wrapskirt', L(['wrap skirt', 'sarong', 'lappa', 'wrapper', 'iro', 'pareo']), { hem: 'midi', flare: 10, wrap: true }, SKN, ['#d9a21b']);
SK('tieredskirt', L(['tiered skirt', 'prairie skirt', 'ruffle skirt', 'gypsy skirt']), { hem: 'shin', flare: 22, tiers: 3 }, SKN, ['#c8643d']);
SK('hakama', L(['hakama', 'samurai skirt']), { hem: 'ankle', flare: 18, pleats: true }, SKN, ['#1b2a5a']);

// ---- dresses (bodice + skirt in one piece)
function DR(id, aka, bod, sk, nat, col, cat = 'dress') {
  const top = makeTop({ hem: 'waist', sag: 0, ...bod });
  const skirt = makeBottom({ skirt: true, rise: 'waist', ...sk });
  def(id, 'dress', { cat, aka, col, nat, draw: (K, a) => { const t = top(K, a), s = skirt(K, { ...a, col2: a.col2 }); return { back: t.back, mid: s.mid + t.mid, front: t.front }; } });
}
const DN = { s: 'tshirt', h: 'dress', arm: 'skin', dress: true };
DR('sundress', L(['sundress', 'summer dress', 'day dress', 'casual dress']), { neck: 'scoop', sleeve: 'none', fit: -2 }, { hem: 'knee', flare: 14 }, DN, ['#f2a516']);
DR('dress', L(['dress', 'frock', 'midi dress', 'work dress']), { neck: 'v', sleeve: 'short' }, { hem: 'midi', flare: 12 }, DN, ['#2f6fd6']);
DR('longsleevedress', L(['long sleeve dress', 'winter dress', 'sweater dress']), { neck: 'crew', sleeve: 'long', fit: 3 }, { hem: 'knee', flare: 10 }, { ...DN, arm: 'cloth', s: 'sweater' }, ['#6b4423']);
DR('minidress', L(['mini dress', 'short dress', 'party dress', 'cocktail dress', 'little black dress']), { neck: 'scoop', sleeve: 'none', fit: -3 }, { hem: 'mini', flare: 8 }, DN, ['#1c1c20']);
DR('maxidress', L(['maxi dress', 'long dress', 'floor length dress', 'boho dress']), { neck: 'v', sleeve: 'short' }, { hem: 'ankle', flare: 18 }, DN, ['#8a4fd6']);
DR('gown', L(['gown', 'evening gown', 'ball gown', 'prom dress', 'formal dress', 'princess dress', 'princess gown']), { neck: 'square', sleeve: 'none', fit: -3, det: ['ruffle'] }, { hem: 'floor', flare: 40, spread: 0.2 }, DN, ['#c2307e']);
DR('wedding', L(['wedding dress', 'bridal gown', 'bride dress', 'wedding gown']), { neck: 'strapless', sleeve: 'none', fit: -3 }, { hem: 'floor', flare: 44, spread: 0.2, layers: true }, DN, ['#f5f5f2']);
DR('pinafore', L(['pinafore', 'jumper dress', 'pinafore dress', 'maid dress', 'maid outfit']), { neck: 'square', sleeve: 'none', det: ['apronBib'] }, { hem: 'knee', flare: 14 }, DN, ['#1b2a5a']);
DR('qipao', L(['qipao', 'cheongsam', 'chinese dress']), { neck: 'mandarin', sleeve: 'cap', fit: -3 }, { hem: 'shin', flare: 0, spread: 0 }, DN, ['#d32f2f']);
DR('sari', L(['sari', 'saree', 'indian dress', 'lehenga']), { neck: 'boat', sleeve: 'short', fit: -3, det: ['sash'] }, { hem: 'floor', flare: 16 }, DN, ['#d63aa0']);
DR('kaftan', L(['kaftan', 'caftan', 'abaya', 'jalabiya', 'thobe', 'thawb', 'dishdasha', 'kandura', 'gown long', 'agbada', 'boubou', 'senegalese boubou']), { neck: 'v', sleeve: 'long', fit: 14 }, { hem: 'floor', flare: 6, spread: 0.02 }, { ...DN, arm: 'cloth' }, ['#f5f5f2']);
DR('nightgown', L(['nightgown', 'nightie', 'sleep dress', 'nightdress']), { neck: 'scoop', sleeve: 'none', fit: 2 }, { hem: 'shin', flare: 10 }, DN, ['#b9a4e6']);
DR('hospitalgown', L(['hospital gown', 'patient gown']), { neck: 'v', sleeve: 'short', fit: 6 }, { hem: 'thigh', flare: 4, spread: 0.02 }, DN, ['#7cc4ee']);
DR('toga', L(['toga', 'roman toga', 'greek tunic', 'chiton']), { neck: 'v', sleeve: 'none', det: ['sash'] }, { hem: 'shin', flare: 10 }, DN, ['#f3ecd8']);
DR('monkrobe', L(['monk robe', 'monk habit', 'habit', 'friar robe', 'cassock', 'priest robe', 'nun habit', 'nun dress']), { neck: 'v', sleeve: 'long', fit: 12, det: ['belt'] }, { hem: 'floor', flare: 8, spread: 0.04 }, { ...DN, arm: 'cloth' }, ['#4a2c1a']);
DR('wizardrobe', L(['wizard robe', 'sorcerer robe', 'mage robe', 'witch dress', 'witch robe']), { neck: 'v', sleeve: 'long', fit: 14, det: ['sash'] }, { hem: 'floor', flare: 20 }, { ...DN, arm: 'cloth' }, ['#3b3a9a']);
DR('judgerobe', L(['judge robe', 'graduation gown', 'academic gown', 'court robe', 'barrister robe']), { neck: 'v', sleeve: 'long', fit: 14 }, { hem: 'floor', flare: 8, spread: 0.04 }, { ...DN, arm: 'cloth' }, ['#1c1c20']);
// ---- one-piece suits
function JS(id, aka, bod, sk, nat, col) {
  const top = makeTop({ hem: 'bottom', ...bod }), bot = makeBottom({ hem: 'ankle', rise: 'bottom', ...sk });
  def(id, 'dress', { cat: 'suit', aka, col, nat, draw: (K, a) => { const t = top(K, a), b = bot(K, a); return { back: t.back, mid: b.mid + t.mid, front: t.front }; } });
}
const JN = { s: 'jacket', h: 'coat', arm: 'cloth', dress: true };
JS('jumpsuit', L(['jumpsuit', 'boiler suit', 'coveralls', 'mechanic suit', 'work suit', 'flight suit', 'prison jumpsuit', 'overall suit']), { neck: 'collar', sleeve: 'long', fit: 4, det: ['zip', 'pocket', 'belt'] }, { wide: 2 }, JN, ['#3b4a7a']);
JS('spacesuit', L(['space suit', 'spacesuit', 'astronaut suit', 'astronaut']), { neck: 'turtle', sleeve: 'long', fit: 16, det: ['zip', 'chestband', 'logo'] }, { wide: 8 }, JN, ['#f5f5f2']);
JS('hazmat', L(['hazmat suit', 'hazmat', 'protective suit', 'bunny suit']), { neck: 'hood', sleeve: 'long', fit: 14, det: ['zip'] }, { wide: 8 }, JN, ['#f7e65a']);
JS('wetsuit', L(['wetsuit', 'diving suit', 'surf suit', 'swimsuit full']), { neck: 'crew', sleeve: 'long', fit: -4, det: ['zip', 'stripeH'] }, { wide: -2 }, JN, ['#1c1c20']);
JS('ninjasuit', L(['ninja suit', 'ninja outfit', 'shinobi suit', 'stealth suit', 'catsuit']), { neck: 'mandarin', sleeve: 'long', fit: -2, det: ['belt'] }, { wide: 0 }, JN, ['#1c1c20']);
JS('superhero', L(['superhero suit', 'hero suit', 'spandex suit', 'super suit', 'costume suit']), { neck: 'crew', sleeve: 'long', fit: -3, det: ['chestband', 'belt', 'logo'] }, { wide: -1 }, JN, ['#2f6fd6']);
JS('onesie', L(['onesie', 'footie pajamas', 'animal onesie', 'romper suit', 'romper']), { neck: 'hood', sleeve: 'long', fit: 10, det: ['zip', 'kangaroo'] }, { wide: 5 }, JN, ['#f08fb0']);
JS('karateuniform', L(['karate uniform', 'martial arts gi']), { neck: 'v', sleeve: 'three', fit: 8, det: ['wrap', 'belt'] }, { wide: 8, hem: 'shin' }, JN, ['#f5f5f2']);
JS('swimsuit', L(['swimsuit', 'one piece swimsuit', 'bathing suit', 'one-piece', 'swimwear']), { neck: 'scoop', sleeve: 'none', fit: -4, hem: 'bottom' }, { hem: 'bottom', wide: -4 }, { s: 'tank', h: 'tshirt', arm: 'skin', dress: true }, ['#d63aa0']);
JS('bikini', L(['bikini', 'two piece swimsuit', 'bikini top', 'beachwear']), { neck: 'halter', sleeve: 'none', fit: -4, hem: 'crop' }, { hem: 'bottom', wide: -4 }, { s: 'tank', h: 'tshirt', arm: 'skin', dress: true }, ['#ff7f6e']);
JS('ballet', L(['ballet outfit', 'dance leotard', 'dancer outfit', 'gymnast', 'gymnastics leotard', 'ballerina']), { neck: 'scoop', sleeve: 'none', fit: -4, hem: 'bottom' }, { hem: 'bottom', wide: -4 }, { s: 'tank', h: 'tshirt', arm: 'skin', dress: true }, ['#f3b8c4']);

// ------------------------------------------------------------------ HEADWEAR (drawn on the head: it moves, nods and turns with the head)
function headBox(K) { const H = K.B.head; return { x: H.x || 0, y: H.y, rx: H.rx, ry: H.ry, top: H.y - H.ry, brow: H.y - H.ry * (K.B.style === 'human' ? 0.55 : 0.38), ear: H.rx }; }
const hatSvg = {
  cap(K, a, h, o) {
    const c = K.cloth(a.col, a.pat, a.col2), br = o.brim || 0.5;
    const crown = `M${h.x - h.rx * 1.0},${h.brow} Q${h.x - h.rx * 1.02},${h.top - h.ry * 0.12} ${h.x},${h.top - h.ry * 0.1} Q${h.x + h.rx * 1.02},${h.top - h.ry * 0.12} ${h.x + h.rx * 1.0},${h.brow}Z`;
    const visor = `M${h.x - h.rx * 1.02},${h.brow} Q${h.x},${h.brow + h.ry * (0.26 + br * 0.3)} ${h.x + h.rx * 1.02},${h.brow} Q${h.x},${h.brow + h.ry * 0.04} ${h.x - h.rx * 1.02},${h.brow}Z`;
    return `<path d="${crown}" ${K.st(c)}/>${K.shadeOver(crown)}<path d="${visor}" ${K.st(K.dk(a.col2 && !a.pat ? a.col2 : a.col))}/><circle cx="${h.x}" cy="${h.top - h.ry * 0.1}" r="${h.rx * 0.06}" ${K.st(K.lt(a.col), 0.6)}/><path d="M${h.x},${h.top - h.ry * 0.08} V${h.brow}" ${K.ln(0.4)}/>${o.logo ? `<circle cx="${h.x}" cy="${h.top + h.ry * 0.5}" r="${h.rx * 0.14}" ${K.st(a.col2 || '#fff', 0.6)}/>` : ''}`;
  },
  beanie(K, a, h, o) {
    const c = K.cloth(a.col, a.pat, a.col2), top = h.top - h.ry * (o.tall || 0.16);
    const body = `M${h.x - h.rx * 1.02},${h.brow + h.ry * 0.06} Q${h.x - h.rx * 1.08},${top} ${h.x},${top} Q${h.x + h.rx * 1.08},${top} ${h.x + h.rx * 1.02},${h.brow + h.ry * 0.06}Z`;
    let s = `<path d="${body}" ${K.st(c)}/>${K.shadeOver(body)}`;
    s += `<rect x="${h.x - h.rx * 1.04}" y="${h.brow - h.ry * 0.1}" width="${h.rx * 2.08}" height="${h.ry * 0.24}" rx="${h.ry * 0.1}" ${K.st(K.dk(a.col2 && !a.pat ? a.col2 : a.col))}/>`;
    if (o.pom) s += `<circle cx="${h.x}" cy="${top - h.ry * 0.08}" r="${h.rx * 0.18}" ${K.st(K.lt(a.col2 || a.col))}/>`;
    return s;
  },
  bucket(K, a, h) {
    const c = K.cloth(a.col, a.pat, a.col2);
    const crown = `M${h.x - h.rx * 0.9},${h.brow} L${h.x - h.rx * 0.78},${h.top - h.ry * 0.12} Q${h.x},${h.top - h.ry * 0.2} ${h.x + h.rx * 0.78},${h.top - h.ry * 0.12} L${h.x + h.rx * 0.9},${h.brow}Z`;
    const brim = `M${h.x - h.rx * 1.35},${h.brow + h.ry * 0.22} Q${h.x},${h.brow - h.ry * 0.12} ${h.x + h.rx * 1.35},${h.brow + h.ry * 0.22} Q${h.x},${h.brow + h.ry * 0.5} ${h.x - h.rx * 1.35},${h.brow + h.ry * 0.22}Z`;
    return `<path d="${brim}" ${K.st(K.dk(a.col))}/><path d="${crown}" ${K.st(c)}/>${K.shadeOver(crown)}`;
  },
  brimmed(K, a, h, o) { // fedora, trilby, panama, cowboy, sun hat, straw hat, bowler
    const c = K.cloth(a.col, a.pat, a.col2), bw = o.bw || 1.5, ch = o.ch || 0.5, pinch = o.pinch;
    const top = h.top - h.ry * ch;
    const crown = o.round
      ? `M${h.x - h.rx * 0.88},${h.brow} Q${h.x - h.rx * 0.92},${top} ${h.x},${top} Q${h.x + h.rx * 0.92},${top} ${h.x + h.rx * 0.88},${h.brow}Z`
      : `M${h.x - h.rx * 0.9},${h.brow} L${h.x - h.rx * 0.74},${top + h.ry * 0.12} Q${h.x - h.rx * 0.4},${top - (pinch ? h.ry * 0.1 : 0)} ${h.x},${top + (pinch ? h.ry * 0.22 : 0)} Q${h.x + h.rx * 0.4},${top - (pinch ? h.ry * 0.1 : 0)} ${h.x + h.rx * 0.74},${top + h.ry * 0.12} L${h.x + h.rx * 0.9},${h.brow}Z`;
    const up = o.up ? h.ry * 0.28 : 0;
    const brim = `M${h.x - h.rx * bw},${h.brow + h.ry * 0.14 - up} Q${h.x - h.rx * bw * 0.5},${h.brow - h.ry * 0.16} ${h.x},${h.brow - h.ry * 0.1} Q${h.x + h.rx * bw * 0.5},${h.brow - h.ry * 0.16} ${h.x + h.rx * bw},${h.brow + h.ry * 0.14 - up} Q${h.x},${h.brow + h.ry * (0.46 - (o.flat ? 0.1 : 0))} ${h.x - h.rx * bw},${h.brow + h.ry * 0.14 - up}Z`;
    const band = a.col2 && !a.pat ? a.col2 : K.dk(a.col);
    return `<path d="${brim}" ${K.st(K.dk(a.col, 0.9))}/><path d="${crown}" ${K.st(c)}/>${K.shadeOver(crown)}<path d="M${h.x - h.rx * 0.9},${h.brow - h.ry * 0.02} Q${h.x},${h.brow + h.ry * 0.08} ${h.x + h.rx * 0.9},${h.brow - h.ry * 0.02}" fill="none" stroke="${band}" stroke-width="${h.ry * 0.16}"/>${o.feather ? `<path d="M${h.x + h.rx * 0.55},${h.brow} q${h.rx * 0.3},${-h.ry * 0.5} ${h.rx * 0.1},${-h.ry * 0.9} q${-h.rx * 0.2},${h.ry * 0.4} ${-h.rx * 0.3},${h.ry * 0.9}z" ${K.st('#d32f2f', 0.6)}/>` : ''}`;
  },
  tall(K, a, h, o) { // top hat, chef hat, wizard (cone), witch, party, fez, kufi
    const c = K.cloth(a.col, a.pat, a.col2), H2 = h.ry * (o.h || 1.0), top = h.top - H2;
    let crown;
    if (o.cone) crown = `M${h.x - h.rx * 0.95},${h.brow} Q${h.x - h.rx * 0.5},${h.top - H2 * 0.3} ${h.x + (o.lean || 0) * h.rx},${top} Q${h.x + h.rx * 0.5},${h.top - H2 * 0.3} ${h.x + h.rx * 0.95},${h.brow}Z`;
    else if (o.puff) crown = `M${h.x - h.rx * 0.78},${h.brow} Q${h.x - h.rx * 1.25},${h.top - H2 * 0.4} ${h.x - h.rx * 0.5},${top} Q${h.x},${top - h.ry * 0.3} ${h.x + h.rx * 0.5},${top} Q${h.x + h.rx * 1.25},${h.top - H2 * 0.4} ${h.x + h.rx * 0.78},${h.brow}Z`;
    else crown = `M${h.x - h.rx * 0.78},${h.brow} L${h.x - h.rx * (o.taper ? 0.55 : 0.78)},${top} Q${h.x},${top - h.ry * 0.12} ${h.x + h.rx * (o.taper ? 0.55 : 0.78)},${top} L${h.x + h.rx * 0.78},${h.brow}Z`;
    let s = `<path d="${crown}" ${K.st(c)}/>${K.shadeOver(crown)}`;
    if (o.brim) s = `<path d="M${h.x - h.rx * o.brim},${h.brow + h.ry * 0.12} Q${h.x},${h.brow - h.ry * 0.14} ${h.x + h.rx * o.brim},${h.brow + h.ry * 0.12} Q${h.x},${h.brow + h.ry * 0.4} ${h.x - h.rx * o.brim},${h.brow + h.ry * 0.12}Z" ${K.st(K.dk(a.col))}/>` + s;
    if (o.band !== false) s += `<path d="M${h.x - h.rx * 0.8},${h.brow - h.ry * 0.06} Q${h.x},${h.brow + h.ry * 0.06} ${h.x + h.rx * 0.8},${h.brow - h.ry * 0.06}" fill="none" stroke="${a.col2 || (o.chef ? '#ddd' : '#b02a37')}" stroke-width="${h.ry * 0.14}"/>`;
    if (o.star) s += `<circle cx="${h.x}" cy="${top + (h.brow - top) * 0.5}" r="${h.rx * 0.12}" fill="#f7c52b"/>`;
    if (o.tassel) s += `<path d="M${h.x},${top} q${h.rx * 0.6},${h.ry * 0.1} ${h.rx * 0.5},${h.ry * 0.6}" ${K.ln(0.9, '#f2a516')}/>`;
    if (o.pomtip) s += `<circle cx="${h.x + (o.lean || 0) * h.rx}" cy="${top}" r="${h.rx * 0.14}" ${K.st('#f5f5f2', 0.7)}/>`;
    return s;
  },
  helmet(K, a, h, o) { // hard hat, bike, football, army, space, viking, knight, police, firefighter
    const c = K.cloth(a.col, a.pat, a.col2), top = h.top - h.ry * (o.ch || 0.12), w = o.w || 1.04;
    let s = '';
    if (o.bubble) {
      s += `<ellipse cx="${h.x}" cy="${h.y}" rx="${h.rx * 1.3}" ry="${h.ry * 1.22}" fill="#bfe6ff" fill-opacity=".28" stroke="${K.F.ink}" stroke-width="${K.F.sw}"/><path d="M${h.x - h.rx * 0.8},${h.y - h.ry * 0.7} Q${h.x - h.rx * 0.2},${h.y - h.ry * 1.05} ${h.x + h.rx * 0.3},${h.y - h.ry * 1.0}" fill="none" stroke="#fff" stroke-width="${K.F.sw * 1.2}" opacity=".7"/><rect x="${h.x - h.rx * 1.3}" y="${h.y + h.ry * 0.95}" width="${h.rx * 2.6}" height="${h.ry * 0.3}" rx="${h.ry * 0.1}" ${K.st('#c4c8cf')}/>`;
      return s;
    }
    const dome = `M${h.x - h.rx * w},${h.brow + h.ry * (o.low || 0.05)} Q${h.x - h.rx * w * 1.08},${top - h.ry * 0.1} ${h.x},${top} Q${h.x + h.rx * w * 1.08},${top - h.ry * 0.1} ${h.x + h.rx * w},${h.brow + h.ry * (o.low || 0.05)}Z`;
    s += `<path d="${dome}" ${K.st(c)}/>${K.shadeOver(dome)}`;
    if (o.brim) s += `<path d="M${h.x - h.rx * 1.14},${h.brow + h.ry * 0.08} Q${h.x},${h.brow + h.ry * 0.3} ${h.x + h.rx * 1.14},${h.brow + h.ry * 0.08} Q${h.x},${h.brow - h.ry * 0.04} ${h.x - h.rx * 1.14},${h.brow + h.ry * 0.08}Z" ${K.st(K.dk(a.col))}/>`;
    if (o.ridge) s += `<path d="M${h.x},${top} V${h.brow - h.ry * 0.05}" ${K.ln(1.1, K.dk(a.col))}/><path d="M${h.x - h.rx * 0.45},${top + h.ry * 0.08} V${h.brow - h.ry * 0.1} M${h.x + h.rx * 0.45},${top + h.ry * 0.08} V${h.brow - h.ry * 0.1}" ${K.ln(0.6)} opacity=".5"/>`;
    if (o.vents) for (const sg of [-1, 1]) s += `<ellipse cx="${h.x + sg * h.rx * 0.45}" cy="${top + h.ry * 0.35}" rx="${h.rx * 0.1}" ry="${h.ry * 0.16}" fill="${K.dk(a.col)}"/>`;
    if (o.guard) s += `<path d="M${h.x - h.rx * 0.98},${h.brow} V${h.y + h.ry * 0.4} M${h.x + h.rx * 0.98},${h.brow} V${h.y + h.ry * 0.4}" fill="none" stroke="${K.dk(a.col)}" stroke-width="${h.rx * 0.12}"/><path d="M${h.x - h.rx * 0.9},${h.y + h.ry * 0.22} H${h.x + h.rx * 0.9}" ${K.ln(1.3)}/><path d="M${h.x - h.rx * 0.9},${h.y + h.ry * 0.06} H${h.x + h.rx * 0.9}" ${K.ln(1.1)}/>`;
    if (o.nasal) s += `<path d="M${h.x},${h.brow} V${h.y + h.ry * 0.3}" fill="none" stroke="${K.dk(a.col)}" stroke-width="${h.rx * 0.12}"/>`;
    if (o.horns) for (const sg of [-1, 1]) s += `<path d="M${h.x + sg * h.rx * 0.95},${h.brow - h.ry * 0.1} Q${h.x + sg * h.rx * 1.5},${h.brow - h.ry * 0.3} ${h.x + sg * h.rx * 1.35},${h.top - h.ry * 0.5} Q${h.x + sg * h.rx * 1.3},${h.brow - h.ry * 0.5} ${h.x + sg * h.rx * 0.88},${h.brow - h.ry * 0.5}Z" ${K.st('#f3ecd8')}/>`;
    if (o.plume) s += `<path d="M${h.x},${top} q${-h.rx * 0.5},${-h.ry * 0.6} ${h.rx * 0.2},${-h.ry * 0.8} q${h.rx * 0.8},${h.ry * 0.2} ${h.rx * 0.2},${h.ry * 0.8}z" ${K.st('#d32f2f', 0.7)}/>`;
    if (o.badge) s += `<path d="M${h.x},${h.brow - h.ry * 0.62} l${h.rx * 0.14},${h.ry * 0.2} h${-h.rx * 0.28}z" ${K.st('#d4af37', 0.6)}/>`;
    if (o.light) s += `<rect x="${h.x - h.rx * 0.2}" y="${top + h.ry * 0.12}" width="${h.rx * 0.4}" height="${h.ry * 0.2}" rx="${h.ry * 0.06}" fill="#fff6a0" stroke="${K.F.ink}" stroke-width="${K.F.sw * 0.5}"/>`;
    return s;
  },
  band(K, a, h, o) { // headband, sweatband, bandana (on head), bow, scrunchie
    const c = K.cloth(a.col, a.pat, a.col2), th = h.ry * (o.th || 0.18);
    let s = `<path d="M${h.x - h.rx * 1.0},${h.brow - th * 0.2} Q${h.x},${h.brow - h.ry * 0.2 - th * (o.arch || 0)} ${h.x + h.rx * 1.0},${h.brow - th * 0.2} L${h.x + h.rx * 1.0},${h.brow + th} Q${h.x},${h.brow + th - h.ry * 0.18} ${h.x - h.rx * 1.0},${h.brow + th}Z" ${K.st(c)}/>`;
    if (o.knot) s += `<path d="M${h.x + h.rx * 0.95},${h.brow} l${h.rx * 0.5},${-h.ry * 0.2} l${-h.rx * 0.1},${h.ry * 0.5}z M${h.x + h.rx * 0.95},${h.brow} l${h.rx * 0.45},${h.ry * 0.3} l${-h.rx * 0.2},${h.ry * 0.1}z" ${K.st(K.dk(a.col))}/>`;
    if (o.bow) s += `<path d="M${h.x + h.rx * 0.5},${h.top + h.ry * 0.1} l${h.rx * 0.45},${-h.ry * 0.28} v${h.ry * 0.5}z M${h.x + h.rx * 0.5},${h.top + h.ry * 0.1} l${-h.rx * 0.45},${-h.ry * 0.28} v${h.ry * 0.5}z" ${K.st(c)}/><circle cx="${h.x + h.rx * 0.5}" cy="${h.top + h.ry * 0.1}" r="${h.rx * 0.08}" ${K.st(K.dk(a.col))}/>`;
    return s;
  },
  wrap(K, a, h, o) { // turban, hijab, headwrap (gele), hood up, balaclava
    const c = K.cloth(a.col, a.pat, a.col2);
    let s = '';
    if (o.hijab) {
      const d = `M${h.x - h.rx * 1.12},${h.y + h.ry * 0.9} Q${h.x - h.rx * 1.3},${h.top - h.ry * 0.12} ${h.x},${h.top - h.ry * 0.14} Q${h.x + h.rx * 1.3},${h.top - h.ry * 0.12} ${h.x + h.rx * 1.12},${h.y + h.ry * 0.9} Q${h.x + h.rx * 0.9},${h.y + h.ry * 1.5} ${h.x},${h.y + h.ry * 1.55} Q${h.x - h.rx * 0.9},${h.y + h.ry * 1.5} ${h.x - h.rx * 1.12},${h.y + h.ry * 0.9}Z`;
      const hole = `M${h.x - h.rx * 0.82},${h.y + h.ry * 0.2} Q${h.x - h.rx * 0.9},${h.top + h.ry * 0.3} ${h.x},${h.top + h.ry * 0.24} Q${h.x + h.rx * 0.9},${h.top + h.ry * 0.3} ${h.x + h.rx * 0.82},${h.y + h.ry * 0.2} Q${h.x + h.rx * 0.8},${h.y + h.ry * 0.95} ${h.x},${h.y + h.ry * 1.02} Q${h.x - h.rx * 0.8},${h.y + h.ry * 0.95} ${h.x - h.rx * 0.82},${h.y + h.ry * 0.2}Z`;
      return { back: `<path d="${d}" ${K.st(c)}/>`, over: `<path d="${d} ${hole}" fill-rule="evenodd" ${K.st(c)}/>${K.shadeOver(d)}` };
    }
    if (o.balaclava) {
      const d = `M${h.x - h.rx * 1.06},${h.y + h.ry * 1.1} Q${h.x - h.rx * 1.2},${h.top - h.ry * 0.1} ${h.x},${h.top - h.ry * 0.1} Q${h.x + h.rx * 1.2},${h.top - h.ry * 0.1} ${h.x + h.rx * 1.06},${h.y + h.ry * 1.1}Z`;
      const hole = `M${h.x - h.rx * 0.72},${h.y - h.ry * 0.38} h${h.rx * 1.44} v${h.ry * 0.36} h${-h.rx * 1.44}z`;
      return `<path d="${d} ${hole}" fill-rule="evenodd" ${K.st(c)}/>`;
    }
    if (o.hood) {
      const d = `M${h.x - h.rx * 1.2},${h.y + h.ry * 1.0} Q${h.x - h.rx * 1.4},${h.top - h.ry * 0.3} ${h.x},${h.top - h.ry * 0.28} Q${h.x + h.rx * 1.4},${h.top - h.ry * 0.3} ${h.x + h.rx * 1.2},${h.y + h.ry * 1.0} L${h.x + h.rx * 0.9},${h.y + h.ry * 0.5} Q${h.x + h.rx * 1.0},${h.top + h.ry * 0.2} ${h.x},${h.top + h.ry * 0.2} Q${h.x - h.rx * 1.0},${h.top + h.ry * 0.2} ${h.x - h.rx * 0.9},${h.y + h.ry * 0.5}Z`;
      return `<path d="${d}" ${K.st(c)}/>${K.shadeOver(d)}`;
    }
    // turban / gele
    const base = `M${h.x - h.rx * 1.06},${h.brow + h.ry * 0.1} Q${h.x - h.rx * 1.2},${h.top - h.ry * (o.up || 0.3)} ${h.x},${h.top - h.ry * (o.up || 0.3)} Q${h.x + h.rx * 1.2},${h.top - h.ry * (o.up || 0.3)} ${h.x + h.rx * 1.06},${h.brow + h.ry * 0.1}Z`;
    s += `<path d="${base}" ${K.st(c)}/>${K.shadeOver(base)}`;
    for (let i = 0; i < 3; i++) s += `<path d="M${h.x - h.rx * 1.0},${h.brow - h.ry * 0.2 * i} Q${h.x},${h.brow - h.ry * (0.35 + 0.22 * i)} ${h.x + h.rx * 1.0},${h.brow - h.ry * 0.2 * i}" ${K.ln(0.5)} opacity=".7"/>`;
    if (o.gele) s += `<path d="M${h.x + h.rx * 0.2},${h.top - h.ry * 0.3} q${h.rx * 0.9},${-h.ry * 0.5} ${h.rx * 1.1},${h.ry * 0.1} q${-h.rx * 0.5},${h.ry * 0.5} ${-h.rx * 1.1},${-h.ry * 0.1}z" ${K.st(K.lt(a.col))}/>`;
    return s;
  },
  crown(K, a, h, o) {
    const gold = a.pat ? '#d4af37' : a.col;
    const n = o.n || 5, w = h.rx * (o.w || 0.86), y0 = h.top + h.ry * 0.12, ht = h.ry * (o.h || 0.55);
    let d = `M${h.x - w},${y0}`;
    for (let i = 0; i < n; i++) { const x0 = h.x - w + (2 * w) * (i / n), x1 = h.x - w + (2 * w) * ((i + 0.5) / n), x2 = h.x - w + (2 * w) * ((i + 1) / n); d += ` L${x0},${y0 - ht * 0.25} L${x1},${y0 - ht} L${x2},${y0 - ht * 0.25}`; }
    d += ` L${h.x + w},${y0} Q${h.x},${y0 + h.ry * 0.12} ${h.x - w},${y0}Z`;
    let s = `<path d="${d}" ${K.st(gold)}/>${K.shadeOver(d)}`;
    for (let i = 0; i < n; i++) s += `<circle cx="${h.x - w + (2 * w) * ((i + 0.5) / n)}" cy="${y0 - ht}" r="${h.rx * 0.05}" fill="${a.col2 || '#d32f2f'}" stroke="${K.F.ink}" stroke-width="${K.F.sw * 0.4}"/>`;
    s += `<circle cx="${h.x}" cy="${y0 - h.ry * 0.1}" r="${h.rx * 0.08}" fill="${a.col2 || '#2f6fd6'}" stroke="${K.F.ink}" stroke-width="${K.F.sw * 0.4}"/>`;
    return s;
  },
  tiara(K, a, h) { return hatSvg.crown(K, { ...a }, h, { n: 5, w: 0.62, h: 0.34 }); },
  ears(K, a, h, o) { // cat, bunny, bear, devil horns, antennae
    const c = K.cloth(a.col, a.pat, a.col2); let s = '';
    for (const sg of [-1, 1]) {
      const x = h.x + sg * h.rx * (o.sp || 0.62), y = h.top + h.ry * 0.16;
      if (o.kind === 'bunny') s += `<path d="M${x - h.rx * 0.18},${y} Q${x - h.rx * 0.28},${y - h.ry * 1.2} ${x + sg * h.rx * 0.05},${y - h.ry * 1.25} Q${x + h.rx * 0.3},${y - h.ry * 1.1} ${x + h.rx * 0.18},${y}Z" ${K.st(c)}/><path d="M${x - h.rx * 0.07},${y - h.ry * 0.1} Q${x - h.rx * 0.1},${y - h.ry * 0.9} ${x + sg * h.rx * 0.04},${y - h.ry * 0.95} Q${x + h.rx * 0.12},${y - h.ry * 0.8} ${x + h.rx * 0.07},${y - h.ry * 0.1}Z" fill="#f3b8c4"/>`;
      else if (o.kind === 'bear') s += `<circle cx="${x}" cy="${y - h.ry * 0.05}" r="${h.rx * 0.26}" ${K.st(c)}/><circle cx="${x}" cy="${y - h.ry * 0.03}" r="${h.rx * 0.13}" fill="${K.lt(a.col)}"/>`;
      else if (o.kind === 'devil') s += `<path d="M${x - h.rx * 0.14},${y + h.ry * 0.04} Q${x + sg * h.rx * 0.3},${y - h.ry * 0.2} ${x + sg * h.rx * 0.2},${y - h.ry * 0.7} Q${x - sg * h.rx * 0.05},${y - h.ry * 0.3} ${x + h.rx * 0.14},${y + h.ry * 0.04}Z" ${K.st(c)}/>`;
      else if (o.kind === 'antenna') s += `<path d="M${x * 0.5},${y + h.ry * 0.1} Q${x * 0.7},${y - h.ry * 0.7} ${x * 1.1},${y - h.ry * 0.8}" ${K.ln(0.9, K.F.ink)}/><circle cx="${x * 1.1}" cy="${y - h.ry * 0.8}" r="${h.rx * 0.1}" ${K.st(c)}/>`;
      else s += `<path d="M${x - h.rx * 0.26},${y + h.ry * 0.08} L${x - sg * h.rx * 0.06},${y - h.ry * 0.62} L${x + h.rx * 0.26},${y + h.ry * 0.08}Z" ${K.st(c)}/><path d="M${x - h.rx * 0.13},${y + h.ry * 0.05} L${x - sg * h.rx * 0.03},${y - h.ry * 0.34} L${x + h.rx * 0.13},${y + h.ry * 0.05}Z" fill="#f3b8c4"/>`;
    }
    return s;
  },
  halo(K, a, h) { return `<ellipse cx="${h.x}" cy="${h.top - h.ry * 0.3}" rx="${h.rx * 0.7}" ry="${h.ry * 0.16}" fill="none" stroke="${a.col}" stroke-width="${h.ry * 0.12}"/><ellipse cx="${h.x}" cy="${h.top - h.ry * 0.3}" rx="${h.rx * 0.7}" ry="${h.ry * 0.16}" fill="none" stroke="#fff" stroke-width="${h.ry * 0.03}" opacity=".6"/>`; },
  phones(K, a, h) { // headphones over the ears
    const c = a.col;
    return `<path d="M${h.x - h.rx * 1.04},${h.y} Q${h.x - h.rx * 1.1},${h.top - h.ry * 0.28} ${h.x},${h.top - h.ry * 0.28} Q${h.x + h.rx * 1.1},${h.top - h.ry * 0.28} ${h.x + h.rx * 1.04},${h.y}" fill="none" stroke="${K.F.ink}" stroke-width="${h.rx * 0.2 + K.F.sw}" stroke-linecap="round"/><path d="M${h.x - h.rx * 1.04},${h.y} Q${h.x - h.rx * 1.1},${h.top - h.ry * 0.28} ${h.x},${h.top - h.ry * 0.28} Q${h.x + h.rx * 1.1},${h.top - h.ry * 0.28} ${h.x + h.rx * 1.04},${h.y}" fill="none" stroke="${c}" stroke-width="${h.rx * 0.2}" stroke-linecap="round"/>` +
      [-1, 1].map((sg) => `<rect x="${h.x + sg * h.rx * 1.05 - h.rx * 0.2}" y="${h.y - h.ry * 0.3}" width="${h.rx * 0.4}" height="${h.ry * 0.6}" rx="${h.rx * 0.16}" ${K.st(K.dk(c))}/>`).join('');
  },
  flowers(K, a, h) { let s = ''; const cols = [a.col, a.col2 || '#ffd54a', '#f3b8c4', '#fff']; for (let i = 0; i < 7; i++) { const t = -0.95 + i * 0.317, x = h.x + t * h.rx, y = h.top + h.ry * (0.28 - 0.26 * Math.cos(t * 1.5)) - h.ry * 0.02; s += `<circle cx="${x}" cy="${y}" r="${h.rx * 0.11}" ${K.st(cols[i % 4], 0.5)}/><circle cx="${x}" cy="${y}" r="${h.rx * 0.04}" fill="#ffd54a"/>`; } return s; },
  laurel(K, a, h) { let s = ''; for (const sg of [-1, 1]) for (let i = 0; i < 6; i++) { const t = i / 5, x = h.x + sg * h.rx * (0.95 - 0.5 * t), y = h.brow - h.ry * (0.1 + 0.6 * t); s += `<ellipse cx="${x}" cy="${y}" rx="${h.rx * 0.13}" ry="${h.ry * 0.07}" transform="rotate(${sg * (50 - 40 * t)} ${x} ${y})" ${K.st('#4a8a3a', 0.5)}/>`; } return s; },
  visor(K, a, h) { const c = K.cloth(a.col, a.pat, a.col2); return `<path d="M${h.x - h.rx * 1.0},${h.brow - h.ry * 0.05} Q${h.x},${h.brow - h.ry * 0.2} ${h.x + h.rx * 1.0},${h.brow - h.ry * 0.05} L${h.x + h.rx * 1.0},${h.brow + h.ry * 0.12} Q${h.x},${h.brow + h.ry * 0.02} ${h.x - h.rx * 1.0},${h.brow + h.ry * 0.12}Z" ${K.st(K.dk(a.col))}/><path d="M${h.x - h.rx * 1.02},${h.brow + h.ry * 0.1} Q${h.x},${h.brow + h.ry * 0.5} ${h.x + h.rx * 1.02},${h.brow + h.ry * 0.1} Q${h.x},${h.brow + h.ry * 0.14} ${h.x - h.rx * 1.02},${h.brow + h.ry * 0.1}Z" ${K.st(c)}/>`; },
  earflap(K, a, h) { return hatSvg.beanie(K, a, h, { pom: false }) + [-1, 1].map((sg) => `<path d="M${h.x + sg * h.rx * 1.0},${h.brow} Q${h.x + sg * h.rx * 1.22},${h.y + h.ry * 0.5} ${h.x + sg * h.rx * 0.98},${h.y + h.ry * 0.78} Q${h.x + sg * h.rx * 0.78},${h.y + h.ry * 0.5} ${h.x + sg * h.rx * 0.9},${h.brow}Z" ${K.st(K.dk(a.col))}/>`).join(''); },
  grad(K, a, h) { return `<path d="M${h.x - h.rx * 0.95},${h.brow} Q${h.x},${h.brow + h.ry * 0.2} ${h.x + h.rx * 0.95},${h.brow} L${h.x + h.rx * 0.9},${h.top + h.ry * 0.3} Q${h.x},${h.top + h.ry * 0.4} ${h.x - h.rx * 0.9},${h.top + h.ry * 0.3}Z" ${K.st(K.dk(a.col))}/><path d="M${h.x},${h.top - h.ry * 0.05} L${h.x + h.rx * 1.3},${h.top + h.ry * 0.2} L${h.x},${h.top + h.ry * 0.5} L${h.x - h.rx * 1.3},${h.top + h.ry * 0.2}Z" ${K.st(a.col)}/><path d="M${h.x},${h.top + h.ry * 0.2} L${h.x + h.rx * 1.15},${h.top + h.ry * 0.3} v${h.ry * 0.45}" fill="none" stroke="#d4af37" stroke-width="${h.rx * 0.05}"/><circle cx="${h.x + h.rx * 1.15}" cy="${h.top + h.ry * 0.8}" r="${h.rx * 0.07}" fill="#d4af37"/>`; },
};
function HT(id, aka, kind, o, col, nat) {
  def(id, 'head', { cat: 'hat', aka, col, pat: false, nat: nat || {}, draw: (K, a) => {
    if (a.view === 'back' && o.frontOnly) return null;
    const h = headBox(K); const r = hatSvg[kind](K, a, h, o || {});
    if (r && typeof r === 'object') return { back: r.back || '', head: r.over || '' };
    return { head: r || '' };
  } });
}
const HS = { s: 'cap', h: 'headband' };
HT('cap', L(['cap', 'baseball cap', 'snapback', 'trucker hat', 'trucker cap', 'dad cap', 'ball cap']), 'cap', { logo: true }, ['#d32f2f'], { s: 'cap' });
HT('capback', L(['cap backwards', 'backwards cap', 'reversed cap']), 'cap', { brim: 0.1 }, ['#1b2a5a'], { s: 'cap' });
HT('beanie', L(['beanie', 'woolly hat', 'wool hat', 'knit hat', 'winter hat', 'toque', 'skull cap', 'ski hat']), 'beanie', {}, ['#7b3fa8'], { s: 'beanie' });
HT('pombeanie', L(['pom pom beanie', 'bobble hat', 'pom hat']), 'beanie', { pom: true, tall: 0.22 }, ['#d32f2f'], { s: 'beanie' });
HT('bucket', L(['bucket hat', 'fisherman hat', 'safari hat', 'boonie', 'boonie hat']), 'bucket', {}, ['#7a8a2a'], { s: 'bucket' });
HT('fedora', L(['fedora', 'trilby', 'detective hat', 'gangster hat', 'indiana jones hat']), 'brimmed', { bw: 1.4, ch: 0.45, pinch: true }, ['#4a2c1a']);
HT('cowboy', L(['cowboy hat', 'stetson', 'western hat', 'ranger hat', 'sheriff hat']), 'brimmed', { bw: 1.75, ch: 0.5, pinch: true, up: true }, ['#a8703a']);
HT('sunhat', L(['sun hat', 'straw hat', 'beach hat', 'panama hat', 'panama', 'garden hat', 'floppy hat']), 'brimmed', { bw: 1.9, ch: 0.38, round: true, flat: true }, ['#e8d08a']);
HT('sombrero', L(['sombrero', 'mexican hat', 'mariachi hat']), 'brimmed', { bw: 2.3, ch: 0.7, pinch: true, up: true }, ['#d9a21b']);
HT('bowler', L(['bowler', 'bowler hat', 'derby hat', 'melon hat']), 'brimmed', { bw: 1.15, ch: 0.5, round: true }, ['#1c1c20']);
HT('feathercap', L(['feather hat', 'musketeer hat', 'robin hood hat', 'cavalier hat']), 'brimmed', { bw: 1.5, ch: 0.45, feather: true, up: true }, ['#2f5f3a']);
HT('flatcap', L(['flat cap', 'newsboy cap', 'newsboy', 'paperboy cap', 'ivy cap', 'driving cap', 'baker boy']), 'cap', { brim: 0.25 }, ['#6b4423'], { s: 'cap' });
HT('beret', L(['beret', 'french beret', 'artist hat', 'painter hat']), 'tall', { h: 0.26, puff: true, band: false, tassel: true }, ['#d32f2f']);
HT('tophat', L(['top hat', 'magician hat', 'gentleman hat', 'ringmaster hat', 'lincoln hat']), 'tall', { h: 1.0, brim: 1.35 }, ['#1c1c20']);
HT('chefhat', L(['chef hat', 'toque blanche', 'cook hat', 'chefs hat', 'baker hat']), 'tall', { h: 0.9, puff: true, chef: true, band: true }, ['#f5f5f2']);
HT('wizardhat', L(['wizard hat', 'sorcerer hat', 'merlin hat', 'mage hat', 'pointy hat']), 'tall', { h: 1.5, cone: true, brim: 1.45, lean: 0.12, star: true }, ['#3b3a9a']);
HT('witchhat', L(['witch hat', 'halloween hat', 'witch']), 'tall', { h: 1.55, cone: true, brim: 1.6, lean: -0.15 }, ['#1c1c20']);
HT('partyhat', L(['party hat', 'birthday hat', 'cone hat', 'dunce cap', 'dunce hat']), 'tall', { h: 1.2, cone: true, pomtip: true, band: false }, ['#f08fb0']);
HT('santahat', L(['santa hat', 'christmas hat', 'xmas hat', 'father christmas hat']), 'tall', { h: 0.9, cone: true, lean: 0.55, pomtip: true, brim: 1.04 }, ['#d32f2f']);
HT('fez', L(['fez', 'tarboosh']), 'tall', { h: 0.55, taper: true, tassel: true, band: false }, ['#b71c3c']);
HT('kufi', L(['kufi', 'taqiyah', 'prayer cap', 'yarmulke', 'kippah', 'skullcap religious']), 'tall', { h: 0.26, taper: true, band: false }, ['#f5f5f2']);
HT('hardhat', L(['hard hat', 'construction helmet', 'safety helmet', 'builder helmet', 'miner helmet', 'hardhat']), 'helmet', { brim: true, ridge: true, light: false }, ['#f7c52b'], { s: 'cap' });
HT('bikehelmet', L(['bike helmet', 'bicycle helmet', 'cycling helmet', 'skate helmet', 'scooter helmet', 'motorcycle helmet']), 'helmet', { vents: true, ch: 0.1, low: 0.1 }, ['#2f6fd6']);
HT('footballhelmet', L(['football helmet', 'american football helmet', 'rugby headgear', 'hockey helmet']), 'helmet', { guard: true, ridge: true, ch: 0.08, low: 0.2 }, ['#1b2a5a']);
HT('armyhelmet', L(['army helmet', 'military helmet', 'soldier helmet', 'combat helmet', 'steel helmet']), 'helmet', { brim: true, ch: 0.06, w: 1.1 }, ['#5a6b3a']);
HT('spacehelmet', L(['space helmet', 'astronaut helmet', 'fishbowl helmet', 'diving helmet']), 'helmet', { bubble: true }, ['#bfe6ff']);
HT('vikinghelmet', L(['viking helmet', 'viking hat', 'horned helmet']), 'helmet', { horns: true, nasal: true, ch: 0.06 }, ['#8a8f98']);
HT('knighthelmet', L(['knight helmet', 'knights helmet', 'medieval helmet', 'gladiator helmet', 'roman helmet', 'centurion helmet']), 'helmet', { guard: true, plume: true, ch: 0.08 }, ['#c4c8cf']);
HT('policecap', L(['police cap', 'police hat', 'cop hat', 'officer cap', 'captain cap', 'sailor cap', 'pilot cap', 'military cap', 'peaked cap', 'bus driver cap']), 'cap', { brim: 0.35, logo: true }, ['#1b2a5a'], { s: 'cap' });
HT('firehelmet', L(['firefighter helmet', 'fireman helmet', 'fire helmet']), 'helmet', { brim: true, badge: true, ridge: true }, ['#d32f2f']);
HT('headband', L(['headband', 'hair band', 'sweatband', 'sweat band', 'sports headband']), 'band', { th: 0.2 }, ['#d32f2f'], HS);
HT('bandana', L(['bandana', 'headscarf', 'kerchief', 'pirate bandana', 'do-rag', 'durag']), 'band', { th: 0.34, knot: true, arch: 0.2 }, ['#c8302a']);
HT('hairbow', L(['hair bow', 'big bow', 'ribbon bow', 'bow']), 'band', { th: 0.0, bow: true }, ['#f08fb0']);
HT('turban', L(['turban', 'sikh turban', 'pagri', 'dastar', 'sultan turban']), 'wrap', { up: 0.42 }, ['#f5f5f2']);
HT('gele', L(['gele', 'head wrap', 'headwrap', 'african headwrap', 'ankara head tie', 'auto gele']), 'wrap', { gele: true, up: 0.46 }, ['#c8302a']);
HT('hijab', L(['hijab', 'headscarf muslim', 'veil', 'niqab head', 'shayla']), 'wrap', { hijab: true }, ['#f5f5f2']);
HT('hoodup', L(['hood up', 'hood on', 'hooded', 'cloak hood', 'cowl hood']), 'wrap', { hood: true }, ['#363a42']);
HT('balaclavahat', L(['balaclava', 'ski mask', 'robber mask', 'burglar mask']), 'wrap', { balaclava: true }, ['#1c1c20']);
HT('crown', L(['crown', 'king crown', 'queen crown', 'royal crown', 'golden crown']), 'crown', { n: 5 }, ['#d4af37']);
HT('tiara', L(['tiara', 'princess tiara', 'pageant crown', 'diadem']), 'tiara', {}, ['#c4c8cf']);
HT('catears', L(['cat ears', 'kitty ears', 'neko ears', 'fox ears', 'wolf ears']), 'ears', { kind: 'cat' }, ['#1c1c20']);
HT('bunnyears', L(['bunny ears', 'rabbit ears', 'easter ears']), 'ears', { kind: 'bunny', sp: 0.42 }, ['#f5f5f2']);
HT('bearears', L(['bear ears', 'mouse ears', 'panda ears', 'teddy ears']), 'ears', { kind: 'bear', sp: 0.7 }, ['#7a4a2a']);
HT('devilhorns', L(['devil horns', 'demon horns', 'horns', 'imp horns']), 'ears', { kind: 'devil', sp: 0.5 }, ['#d32f2f']);
HT('antennae', L(['antennae', 'alien antennae', 'bug antennae', 'deely bobbers']), 'ears', { kind: 'antenna', sp: 0.4 }, ['#39ff88']);
HT('halo', L(['halo', 'angel halo', 'saint halo']), 'halo', {}, ['#f7c52b']);
HT('headphones', L(['headphones', 'earphones over ear', 'gaming headset', 'dj headphones', 'headset']), 'phones', {}, ['#1c1c20'], { s: 'headphones' });
HT('flowercrown', L(['flower crown', 'flower wreath', 'floral crown', 'daisy crown']), 'flowers', {}, ['#f08fb0']);
HT('laurel', L(['laurel wreath', 'laurel crown', 'olive wreath', 'victory wreath', 'caesar wreath']), 'laurel', {}, ['#4a8a3a']);
HT('visor', L(['visor', 'sun visor', 'golf visor', 'tennis visor']), 'visor', {}, ['#f5f5f2']);
HT('earflaps', L(['ushanka', 'earflap hat', 'trapper hat', 'russian hat', 'fur hat']), 'earflap', {}, ['#6b4423']);
HT('gradcap', L(['graduation cap', 'mortarboard', 'grad cap', 'graduation hat', 'academic cap']), 'grad', {}, ['#1c1c20']);
HT('nursecap', L(['nurse cap', 'nurse hat']), 'tall', { h: 0.3, taper: true, band: false, cross: true }, ['#f5f5f2']);

// ------------------------------------------------------------------ EYEWEAR, FACE, EARS, JEWELLERY (drawn on the head)
function eyeBox(K) { const B = K.B, H = B.head; return { x: H.x || 0, y: B.eye.y, dx: B.eye.dx, r: Math.max(B.eye.dx * 0.62, H.rx * 0.2), rx: H.rx, ry: H.ry, hy: H.y, hx: H.x || 0 }; }
function glassesDraw(shape, o = {}) {
  return (K, a) => {
    if (a.view === 'back') return { head: `<path d="M${-K.B.head.rx},${K.B.eye.y} H${K.B.head.rx}" ${K.ln(0.8, K.dk(a.col))}/>` };
    const e = eyeBox(K), c = a.col, lens = o.lens || null, sw = K.F.sw * (o.w || 0.8);
    const lensFill = lens ? lens : 'rgba(190,225,255,.25)';
    let s = '';
    const one = (cx) => {
      const r = e.r;
      if (shape === 'round') return `<circle cx="${cx}" cy="${e.y}" r="${r}" fill="${lensFill}" stroke="${c}" stroke-width="${sw}"/>`;
      if (shape === 'square') return `<rect x="${cx - r * 1.1}" y="${e.y - r * 0.85}" width="${r * 2.2}" height="${r * 1.7}" rx="${r * 0.2}" fill="${lensFill}" stroke="${c}" stroke-width="${sw}"/>`;
      if (shape === 'aviator') return `<path d="M${cx - r * 1.15},${e.y - r * 0.8} H${cx + r * 1.15} Q${cx + r * 1.2},${e.y + r * 1.25} ${cx},${e.y + r * 1.1} Q${cx - r * 1.2},${e.y + r * 1.25} ${cx - r * 1.15},${e.y - r * 0.8}Z" fill="${lensFill}" stroke="${c}" stroke-width="${sw}"/>`;
      if (shape === 'cat') return `<path d="M${cx - r * 1.1},${e.y - r * 0.2} Q${cx - r * 1.2},${e.y - r * 0.9} ${cx + r * (cx < 0 ? -0.2 : 1.35)},${e.y - r * (cx < 0 ? 1.1 : 0.8)} L${cx + r * 1.1},${e.y + r * 0.1} Q${cx + r * 0.4},${e.y + r * 1.1} ${cx - r * 0.5},${e.y + r * 0.9}Z" fill="${lensFill}" stroke="${c}" stroke-width="${sw}"/>`;
      if (shape === 'heart') return `<path d="M${cx},${e.y + r} C${cx - r * 1.6},${e.y - r * 0.2} ${cx - r * 0.8},${e.y - r * 1.2} ${cx},${e.y - r * 0.4} C${cx + r * 0.8},${e.y - r * 1.2} ${cx + r * 1.6},${e.y - r * 0.2} ${cx},${e.y + r}Z" fill="${lensFill}" stroke="${c}" stroke-width="${sw}"/>`;
      if (shape === 'star') { let d = ''; for (let i = 0; i < 10; i++) { const t = -Math.PI / 2 + i * Math.PI / 5, rr = i % 2 ? r * 0.55 : r * 1.25; d += (i ? 'L' : 'M') + (cx + Math.cos(t) * rr).toFixed(1) + ',' + (e.y + Math.sin(t) * rr).toFixed(1); } return `<path d="${d}Z" fill="${lensFill}" stroke="${c}" stroke-width="${sw}"/>`; }
      if (shape === 'goggles') return `<circle cx="${cx}" cy="${e.y}" r="${r * 1.12}" fill="${lensFill}" stroke="${c}" stroke-width="${sw * 2.2}"/><circle cx="${cx}" cy="${e.y}" r="${r * 1.12}" fill="none" stroke="${K.F.ink}" stroke-width="${sw * 0.4}"/>`;
      if (shape === 'half') return `<path d="M${cx - r * 1.1},${e.y - r * 0.4} H${cx + r * 1.1} Q${cx + r * 1.1},${e.y + r * 0.8} ${cx},${e.y + r * 0.8} Q${cx - r * 1.1},${e.y + r * 0.8} ${cx - r * 1.1},${e.y - r * 0.4}Z" fill="${lensFill}" stroke="${c}" stroke-width="${sw}"/>`;
      return `<circle cx="${cx}" cy="${e.y}" r="${r}" fill="${lensFill}" stroke="${c}" stroke-width="${sw}"/>`;
    };
    if (shape === 'monocle') return { head: `<circle cx="${e.x + e.dx}" cy="${e.y}" r="${e.r * 1.1}" fill="rgba(190,225,255,.25)" stroke="${a.col}" stroke-width="${sw * 1.3}"/><path d="M${e.x + e.dx - e.r * 0.8},${e.y + e.r * 0.8} Q${e.x + e.dx - e.r * 0.6},${e.y + e.r * 3} ${e.x + e.dx - e.r * 0.2},${e.y + e.r * 4.2}" ${K.ln(0.4, '#d4af37')}/>` };
    if (shape === 'eyepatch') return { head: `<path d="M${e.x - e.rx},${e.y - e.ry * 0.5} L${e.x + e.dx * 0.1},${e.y + e.r * 0.2}" stroke="${K.dk(a.col)}" stroke-width="${sw * 1.1}"/><ellipse cx="${e.x - e.dx}" cy="${e.y}" rx="${e.r * 1.05}" ry="${e.r * 0.95}" ${K.st(a.col)}/>` };
    if (shape === 'vr') return { head: `<rect x="${e.x - e.rx * 1.02}" y="${e.y - e.r * 1.4}" width="${e.rx * 2.04}" height="${e.r * 2.8}" rx="${e.r * 0.7}" ${K.st(a.col)}/><rect x="${e.x - e.rx * 0.8}" y="${e.y - e.r * 0.8}" width="${e.rx * 1.6}" height="${e.r * 1.6}" rx="${e.r * 0.4}" fill="#111" opacity=".6"/><path d="M${e.x - e.rx * 1.0},${e.y} H${-e.rx * 1.08} M${e.x + e.rx},${e.y} H${e.rx * 1.08}" ${K.ln(1)}/>` };
    s += one(e.x - e.dx) + one(e.x + e.dx);
    if (shape === 'round' || shape === 'square' || shape === 'aviator' || shape === 'cat' || shape === 'half' || shape === 'heart' || shape === 'star') s += `<path d="M${e.x - e.dx + e.r},${e.y - e.r * 0.1} Q${e.x},${e.y - e.r * 0.55} ${e.x + e.dx - e.r},${e.y - e.r * 0.1}" fill="none" stroke="${c}" stroke-width="${sw}"/>`;
    if (shape === 'goggles') s += `<path d="M${e.x - e.rx * 1.02},${e.y} H${e.x - e.dx - e.r * 1.1} M${e.x + e.dx + e.r * 1.1},${e.y} H${e.x + e.rx * 1.02}" stroke="${K.dk(a.col)}" stroke-width="${e.r * 0.7}"/>`;
    s += `<path d="M${e.x - e.dx - e.r * 1.05},${e.y - e.r * 0.2} L${e.x - e.rx * 1.0},${e.y - e.r * 0.1} M${e.x + e.dx + e.r * 1.05},${e.y - e.r * 0.2} L${e.x + e.rx * 1.0},${e.y - e.r * 0.1}" fill="none" stroke="${c}" stroke-width="${sw}"/>`;
    return { head: s };
  };
}
function GL(id, aka, shape, o, col, nat) { def(id, 'eyes', { cat: 'glasses', aka, col, pat: false, nat: nat || {}, draw: glassesDraw(shape, o) }); }
GL('roundglasses', L(['round glasses', 'glasses', 'specs', 'spectacles', 'harry potter glasses', 'reading glasses', 'nerd glasses', 'eyeglasses']), 'round', {}, ['#2a2a2e'], { s: 'round', h: 'round' });
GL('squareglasses', L(['square glasses', 'rectangle glasses', 'office glasses', 'rectangular glasses', 'black frame glasses', 'thick glasses']), 'square', {}, ['#1c1c20'], { s: 'square', h: 'square' });
GL('sunglasses', L(['sunglasses', 'shades', 'dark glasses', 'sun glasses', 'cool glasses', 'wayfarers', 'wayfarer']), 'square', { lens: '#14141a', w: 1.1 }, ['#1c1c20'], { s: 'shades', h: 'sunglasses' });
GL('aviators', L(['aviators', 'aviator sunglasses', 'pilot sunglasses', 'police sunglasses', 'cop sunglasses']), 'aviator', { lens: '#3a3a28' }, ['#d4af37'], { s: 'shades', h: 'sunglasses' });
GL('catglasses', L(['cat eye glasses', 'cat-eye glasses', 'retro glasses', 'vintage glasses']), 'cat', {}, ['#c2307e'], { s: 'round', h: 'round' });
GL('heartshades', L(['heart sunglasses', 'heart glasses', 'love glasses', 'heart shades']), 'heart', { lens: '#e8788f' }, ['#d32f2f'], { s: 'pinkshades' });
GL('starshades', L(['star sunglasses', 'star glasses', 'party glasses', 'novelty glasses']), 'star', { lens: '#f7c52b' }, ['#d32f2f']);
GL('goggles', L(['goggles', 'safety goggles', 'lab goggles', 'swim goggles', 'ski goggles', 'steampunk goggles', 'aviator goggles', 'welding goggles']), 'goggles', {}, ['#f2a516']);
GL('halfglasses', L(['half moon glasses', 'granny glasses', 'half glasses', 'librarian glasses', 'reading specs']), 'half', {}, ['#8a8f98']);
GL('monocle', L(['monocle', 'single lens']), 'monocle', {}, ['#d4af37']);
GL('eyepatch', L(['eyepatch', 'eye patch', 'pirate patch']), 'eyepatch', {}, ['#1c1c20']);
GL('vrheadset', L(['vr headset', 'vr', 'virtual reality headset', 'oculus', 'ar glasses', 'smart glasses visor']), 'vr', {}, ['#e0e0e0']);

function faceDraw(kind) {
  return (K, a) => {
    if (a.view === 'back') return null;
    const B = K.B, H = B.head, e = eyeBox(K), my = B.mouth.y, c = a.col;
    let s = '';
    const mw = H.rx * 0.78;
    if (kind === 'surgical' || kind === 'n95') {
      const top = e.y + e.r * 1.35, bot = my + H.ry * 0.38;
      s += `<path d="M${-mw},${top} Q0,${top - H.ry * 0.08} ${mw},${top} L${mw * 0.96},${bot - H.ry * 0.1} Q0,${bot + H.ry * 0.12} ${-mw * 0.96},${bot - H.ry * 0.1}Z" ${K.st(c)}/>`;
      if (kind === 'surgical') for (let i = 1; i <= 3; i++) s += `<path d="M${-mw * 0.9},${top + (bot - top) * i * 0.25} Q0,${top + (bot - top) * i * 0.25 + H.ry * 0.06} ${mw * 0.9},${top + (bot - top) * i * 0.25}" ${K.ln(0.35)} opacity=".6"/>`;
      s += `<path d="M${-mw},${top + H.ry * 0.05} L${-H.rx * 1.0},${e.y + e.r} M${mw},${top + H.ry * 0.05} L${H.rx * 1.0},${e.y + e.r}" ${K.ln(0.5)}/>`;
    } else if (kind === 'bandit') {
      s += `<path d="M${-mw},${e.y - e.r * 1.3} Q0,${e.y - e.r * 1.6} ${mw},${e.y - e.r * 1.3} L${mw * 1.1},${e.y + e.r * 1.0} Q${e.dx},${e.y + e.r * 1.6} 0,${e.y + e.r * 0.5} Q${-e.dx},${e.y + e.r * 1.6} ${-mw * 1.1},${e.y + e.r * 1.0}Z" ${K.st(c)}/><ellipse cx="${-e.dx}" cy="${e.y}" rx="${e.r * 0.8}" ry="${e.r * 0.55}" fill="#111"/><ellipse cx="${e.dx}" cy="${e.y}" rx="${e.r * 0.8}" ry="${e.r * 0.55}" fill="#111"/>`;
    } else if (kind === 'ninja' || kind === 'scarfmask') {
      const top = e.y + e.r * 0.9;
      s += `<path d="M${-mw * 1.1},${top} Q0,${top - H.ry * 0.05} ${mw * 1.1},${top} L${mw * 1.1},${H.y + H.ry * 1.05} Q0,${H.y + H.ry * 1.2} ${-mw * 1.1},${H.y + H.ry * 1.05}Z" ${K.st(c)}/>`;
    } else if (kind === 'gas') {
      s += `<path d="M${-mw},${e.y + e.r * 0.6} Q0,${e.y + e.r * 0.2} ${mw},${e.y + e.r * 0.6} L${mw * 0.8},${H.y + H.ry * 1.0} Q0,${H.y + H.ry * 1.3} ${-mw * 0.8},${H.y + H.ry * 1.0}Z" ${K.st(c)}/><circle cx="0" cy="${my + H.ry * 0.3}" r="${H.rx * 0.28}" ${K.st(K.dk(c))}/><circle cx="0" cy="${my + H.ry * 0.3}" r="${H.rx * 0.12}" fill="#222"/><circle cx="${-e.dx}" cy="${e.y}" r="${e.r * 1.2}" fill="rgba(180,230,255,.35)" stroke="${K.F.ink}" stroke-width="${K.F.sw}"/><circle cx="${e.dx}" cy="${e.y}" r="${e.r * 1.2}" fill="rgba(180,230,255,.35)" stroke="${K.F.ink}" stroke-width="${K.F.sw}"/>`;
    } else if (kind === 'clown') {
      s += `<circle cx="0" cy="${(e.y + my) / 2 + H.ry * 0.05}" r="${H.rx * 0.13}" ${K.st('#d32f2f', 0.7)}/>`;
    } else if (kind === 'mustache' || kind === 'handlebar') {
      const y = my - H.ry * 0.1;
      s += kind === 'handlebar'
        ? `<path d="M0,${y} Q${-H.rx * 0.3},${y - H.ry * 0.08} ${-H.rx * 0.58},${y + H.ry * 0.02} Q${-H.rx * 0.78},${y + H.ry * 0.08} ${-H.rx * 0.7},${y - H.ry * 0.12} Q${-H.rx * 0.5},${y + H.ry * 0.14} 0,${y + H.ry * 0.05} Q${H.rx * 0.5},${y + H.ry * 0.14} ${H.rx * 0.7},${y - H.ry * 0.12} Q${H.rx * 0.78},${y + H.ry * 0.08} ${H.rx * 0.58},${y + H.ry * 0.02} Q${H.rx * 0.3},${y - H.ry * 0.08} 0,${y}Z" ${K.st(c, 0.6)}/>`
        : `<path d="M0,${y} Q${-H.rx * 0.25},${y - H.ry * 0.1} ${-H.rx * 0.5},${y + H.ry * 0.02} Q${-H.rx * 0.3},${y + H.ry * 0.14} 0,${y + H.ry * 0.06} Q${H.rx * 0.3},${y + H.ry * 0.14} ${H.rx * 0.5},${y + H.ry * 0.02} Q${H.rx * 0.25},${y - H.ry * 0.1} 0,${y}Z" ${K.st(c, 0.6)}/>`;
    } else if (kind === 'beard') {
      s += `<path d="M${-H.rx * 0.95},${H.y} Q${-H.rx * 0.95},${H.y + H.ry * 1.25} 0,${H.y + H.ry * 1.35} Q${H.rx * 0.95},${H.y + H.ry * 1.25} ${H.rx * 0.95},${H.y} Q${H.rx * 0.55},${my - H.ry * 0.05} 0,${my - H.ry * 0.12} Q${-H.rx * 0.55},${my - H.ry * 0.05} ${-H.rx * 0.95},${H.y}Z" ${K.st(c, 0.7)}/>`;
    } else if (kind === 'whiskers') {
      for (const sg of [-1, 1]) s += `<path d="M${sg * H.rx * 0.45},${my - H.ry * 0.12} l${sg * H.rx * 0.5},${-H.ry * 0.08} M${sg * H.rx * 0.45},${my - H.ry * 0.04} l${sg * H.rx * 0.52},${H.ry * 0.02} M${sg * H.rx * 0.45},${my + H.ry * 0.04} l${sg * H.rx * 0.48},${H.ry * 0.12}" ${K.ln(0.5, c)}/>`;
      s += `<path d="M${-H.rx * 0.08},${my - H.ry * 0.2} h${H.rx * 0.16} l${-H.rx * 0.08},${H.ry * 0.08}z" fill="${c}"/>`;
    } else if (kind === 'facepaint') {
      for (const sg of [-1, 1]) s += `<path d="M${sg * (e.dx - e.r)},${e.y + e.r * 1.0} l${sg * e.r * 1.8},${e.r * 0.2} M${sg * (e.dx - e.r * 0.8)},${e.y + e.r * 1.5} l${sg * e.r * 1.8},${e.r * 0.2}" stroke="${c}" stroke-width="${H.rx * 0.06}" stroke-linecap="round"/>`;
    } else if (kind === 'domino') {
      s += `<path d="M${-mw * 1.0},${e.y - e.r * 0.2} Q${-e.dx},${e.y - e.r * 1.5} 0,${e.y - e.r * 0.5} Q${e.dx},${e.y - e.r * 1.5} ${mw * 1.0},${e.y - e.r * 0.2} Q${e.dx * 1.1},${e.y + e.r * 1.2} 0,${e.y + e.r * 0.3} Q${-e.dx * 1.1},${e.y + e.r * 1.2} ${-mw * 1.0},${e.y - e.r * 0.2}Z" ${K.st(c)}/><ellipse cx="${-e.dx}" cy="${e.y}" rx="${e.r * 0.78}" ry="${e.r * 0.5}" fill="#111"/><ellipse cx="${e.dx}" cy="${e.y}" rx="${e.r * 0.78}" ry="${e.r * 0.5}" fill="#111"/>`;
    }
    return { head: s };
  };
}
function FC(id, aka, kind, col, cat = 'face') { def(id, 'face', { cat, aka, col, pat: false, draw: faceDraw(kind) }); }
FC('surgicalmask', L(['surgical mask', 'face mask', 'medical mask', 'covid mask', 'doctor mask', 'mask']), 'surgical', ['#9fd8f0']);
FC('n95', L(['n95', 'respirator', 'ffp2', 'dust mask']), 'n95', ['#f5f5f2']);
FC('banditmask', L(['hero mask', 'superhero mask', 'eye mask', 'bandit mask', 'zorro mask', 'robin mask']), 'bandit', ['#d32f2f']);
FC('domino', L(['domino mask', 'masquerade mask', 'venetian mask', 'party mask', 'phantom mask']), 'domino', ['#f5f5f2']);
FC('ninjamask', L(['ninja mask', 'face scarf', 'neck gaiter', 'gaiter', 'bandana mask', 'covered face', 'shemagh', 'bandit scarf']), 'ninja', ['#1c1c20']);
FC('gasmask', L(['gas mask', 'respirator mask', 'apocalypse mask']), 'gas', ['#5a6b3a']);
FC('clownnose', L(['clown nose', 'red nose', 'rudolph nose']), 'clown', ['#d32f2f']);
FC('mustache', L(['mustache', 'moustache', 'fake mustache', 'stache']), 'mustache', ['#2a1a10']);
FC('handlebar', L(['handlebar mustache', 'handlebar moustache', 'waxed mustache', 'curly mustache', 'villain mustache']), 'handlebar', ['#2a1a10']);
FC('fakebeard', L(['beard', 'full beard', 'fake beard', 'santa beard', 'wizard beard', 'long beard']), 'beard', ['#6b4423']);
FC('whiskers', L(['whiskers', 'cat whiskers', 'cat face paint', 'kitty whiskers']), 'whiskers', ['#1c1c20']);
FC('warpaint', L(['face paint', 'war paint', 'tribal paint', 'tiger stripes face', 'sports face paint']), 'facepaint', ['#d32f2f']);

// ---- ears and jewellery on the head
function jewDraw(kind) {
  return (K, a) => {
    if (a.view === 'back' && kind !== 'earrings') return null;
    const B = K.B, H = B.head, e = eyeBox(K), c = a.col;
    let s = '';
    const ey = e.y + H.ry * 0.28, ex = H.rx * 0.98;
    const r = Math.max(2.5, H.rx * 0.075);
    if (kind === 'earrings') for (const sg of [-1, 1]) s += `<circle cx="${sg * ex}" cy="${ey + r}" r="${r}" ${K.st(c, 0.5)}/>`;
    else if (kind === 'hoops') for (const sg of [-1, 1]) s += `<circle cx="${sg * ex}" cy="${ey + r * 2}" r="${r * 2}" fill="none" stroke="${c}" stroke-width="${Math.max(1.6, r * 0.45)}"/>`;
    else if (kind === 'drops') for (const sg of [-1, 1]) s += `<path d="M${sg * ex},${ey} v${r * 2.6}" ${K.ln(0.3, c)}/><path d="M${sg * ex},${ey + r * 2.2} l${-r * 0.9},${r * 1.5} l${r * 0.9},${r * 1.5} l${r * 0.9},${-r * 1.5}z" ${K.st(a.col2 || c, 0.5)}/>`;
    else if (kind === 'nosering') s += `<circle cx="${H.rx * 0.1}" cy="${(e.y + B.mouth.y) / 2 + H.ry * 0.14}" r="${r * 0.9}" fill="none" stroke="${c}" stroke-width="${Math.max(1.2, r * 0.35)}"/>`;
    else if (kind === 'brow') s += `<circle cx="${e.dx * 1.1}" cy="${e.y - e.r * 1.35}" r="${r * 0.6}" ${K.st(c, 0.4)}/>`;
    else if (kind === 'bindi') s += `<circle cx="0" cy="${e.y - H.ry * 0.28}" r="${r * 0.7}" fill="${c}"/>`;
    else if (kind === 'eyelashes') for (const sg of [-1, 1]) s += `<path d="M${sg * e.dx - e.r},${e.y - e.r * 0.3} l${-e.r * 0.3},${-e.r * 0.3} M${sg * e.dx},${e.y - e.r * 0.9} v${-e.r * 0.4} M${sg * e.dx + e.r},${e.y - e.r * 0.3} l${e.r * 0.3},${-e.r * 0.3}" ${K.ln(0.5, c)}/>`;
    else if (kind === 'lipstick') s += `<path d="M${-H.rx * 0.22},${B.mouth.y} Q0,${B.mouth.y + H.ry * 0.12} ${H.rx * 0.22},${B.mouth.y}" fill="none" stroke="${c}" stroke-width="${H.rx * 0.07}" stroke-linecap="round" opacity=".85"/>`;
    else if (kind === 'blush') for (const sg of [-1, 1]) s += `<ellipse cx="${sg * e.dx * 1.15}" cy="${e.y + e.r * 1.6}" rx="${e.r * 0.9}" ry="${e.r * 0.5}" fill="${c}" opacity=".45"/>`;
    else if (kind === 'freckles') for (const sg of [-1, 1]) for (let i = 0; i < 4; i++) s += `<circle cx="${sg * (e.dx * 0.7 + (i % 2) * r * 1.6)}" cy="${e.y + e.r * 1.4 + (i >> 1) * r * 1.4}" r="${r * 0.28}" fill="${c}" opacity=".8"/>`;
    else if (kind === 'tattoo') s += `<path d="M${-H.rx * 0.8},${e.y + e.r * 1.4} q${H.rx * 0.2},${-H.ry * 0.18} ${H.rx * 0.4},0" ${K.ln(0.5, c)}/>`;
    return { head: s };
  };
}
function JW(id, aka, kind, col) { def(id, 'jewel', { cat: 'jewellery', aka, col, pat: false, draw: jewDraw(kind) }); }
JW('studs', L(['earrings', 'studs', 'stud earrings', 'ear studs', 'pearl earrings']), 'earrings', ['#f5f5f2']);
JW('hoopearrings', L(['hoop earrings', 'hoops', 'big hoops', 'gold hoops']), 'hoops', ['#d4af37']);
JW('dropearrings', L(['drop earrings', 'dangly earrings', 'chandelier earrings', 'gem earrings', 'dangle earrings']), 'drops', ['#d4af37']);
JW('nosering', L(['nose ring', 'nose stud', 'septum ring', 'nose piercing']), 'nosering', ['#c4c8cf']);
JW('browpiercing', L(['eyebrow piercing', 'brow ring']), 'brow', ['#c4c8cf']);
JW('bindi', L(['bindi', 'forehead dot', 'forehead jewel']), 'bindi', ['#d32f2f']);
JW('lashes', L(['lashes', 'eyelashes', 'long lashes', 'false lashes']), 'eyelashes', ['#1c1c20']);
JW('lipstick', L(['lipstick', 'red lips', 'lip colour', 'lip color']), 'lipstick', ['#c2307e']);
JW('blusher', L(['blush', 'rosy cheeks', 'cheek blush']), 'blush', ['#f08fb0']);
JW('freckles', L(['freckles', 'beauty spots']), 'freckles', ['#a8703a']);
JW('facetattoo', L(['face tattoo', 'tattoo']), 'tattoo', ['#1c1c20']);

// ------------------------------------------------------------------ NECKWEAR (drawn over the chest)
function neckDraw(kind, o = {}) {
  return (K, a) => {
    const B = K.B, k = K.k, Y = B.Y, nw = B.neck.w + 6 * k, y0 = Y.sh - 2 * k, c = a.col, back = a.view === 'back';
    let s = '';
    const fill = K.cloth(c, a.pat, a.col2);
    if (back && !['scarf', 'infinity', 'ruff', 'shawl', 'bandananeck'].includes(kind)) return null;
    if (kind === 'scarf' || kind === 'infinity' || kind === 'bandananeck') {
      const th = (kind === 'bandananeck' ? 20 : 24) * k;
      s += `<path d="M${-nw - 8 * k},${y0 - 14 * k} Q0,${y0 - 6 * k + th} ${nw + 8 * k},${y0 - 14 * k} L${nw + 12 * k},${y0 + 4 * k} Q0,${y0 + 8 * k + th} ${-nw - 12 * k},${y0 + 4 * k}Z" ${K.st(fill)}/>`;
      if (kind === 'scarf' && !back) { const tl = (o.long || 64) * k; s += `<path d="M${nw * 0.2},${y0 + 8 * k} L${nw * 1.3},${y0 + 8 * k} L${nw * 1.5},${y0 + tl} L${nw * 0.1},${y0 + tl - 4 * k}Z" ${K.st(fill)}/>` + (a.pat ? '' : `<path d="M${nw * 0.15},${y0 + tl - 10 * k} H${nw * 1.45} M${nw * 0.15},${y0 + tl - 18 * k} H${nw * 1.43}" ${K.ln(0.5, K.lt(c))}/>`); }
      if (kind === 'bandananeck' && !back) s += `<path d="M${-nw - 6 * k},${y0 + 2 * k} L0,${y0 + 40 * k} L${nw + 6 * k},${y0 + 2 * k}Z" ${K.st(fill)}/>`;
      return { front: s };
    }
    if (kind === 'ruff') { for (let i = -5; i <= 5; i++) s += `<circle cx="${i * (nw * 0.32)}" cy="${y0 - 2 * k + Math.abs(i) * 1.6}" r="${nw * 0.24}" ${K.st(K.lt(c), 0.5)}/>`; return { front: s }; }
    if (kind === 'shawl') { s += `<path d="M${-nw * 2.6},${y0 + 4 * k} Q0,${y0 - 6 * k} ${nw * 2.6},${y0 + 4 * k} L${nw * 3},${y0 + 60 * k} Q0,${y0 + 96 * k} ${-nw * 3},${y0 + 60 * k}Z" ${K.st(fill)}/>`; return { front: s }; }
    if (kind === 'tie' || kind === 'skinnytie') {
      const w = (kind === 'skinnytie' ? 6 : 10) * k;
      s += `<path d="M${-w},${y0 + 2 * k} L${w},${y0 + 2 * k} L${w * 0.8},${y0 + 14 * k} L${-w * 0.8},${y0 + 14 * k}Z" ${K.st(K.dk(c))}/><path d="M${-w * 0.8},${y0 + 14 * k} L${w * 0.8},${y0 + 14 * k} L${w * 1.5},${y0 + 82 * k} L0,${y0 + 96 * k} L${-w * 1.5},${y0 + 82 * k}Z" ${K.st(fill)}/>`;
      return { front: s };
    }
    if (kind === 'bowtie') { s += `<path d="M0,${y0 + 6 * k} L${-22 * k},${y0 - 6 * k} V${y0 + 18 * k}Z M0,${y0 + 6 * k} L${22 * k},${y0 - 6 * k} V${y0 + 18 * k}Z" transform="translate(0,0)" ${K.st(fill, 0.8)}/><circle cx="0" cy="${y0 + 6 * k}" r="${4.4 * k}" ${K.st(K.dk(c), 0.7)}/>`; return { front: s }; }
    if (kind === 'bolo') { s += `<path d="M${-nw},${y0} Q0,${y0 + 40 * k} ${nw},${y0}" fill="none" stroke="${K.F.ink}" stroke-width="${2.2 * k}"/><circle cx="0" cy="${y0 + 30 * k}" r="${7 * k}" ${K.st(c)}/>`; return { front: s }; }
    if (kind === 'cravat') { s += `<path d="M${-nw},${y0 - 4 * k} Q0,${y0 + 8 * k} ${nw},${y0 - 4 * k} L${nw * 0.8},${y0 + 26 * k} Q0,${y0 + 38 * k} ${-nw * 0.8},${y0 + 26 * k}Z" ${K.st(fill)}/>`; return { front: s }; }
    if (kind === 'chain' || kind === 'pendant' || kind === 'pearls' || kind === 'choker' || kind === 'beads' || kind === 'lei' || kind === 'medal' || kind === 'dogtags' || kind === 'cross') {
      const depth = { chain: 54, pendant: 62, pearls: 40, choker: 6, beads: 48, lei: 54, medal: 70, dogtags: 60, cross: 64 }[kind] * k;
      const d = `M${-nw * 0.95},${y0 - 6 * k} Q0,${y0 + depth} ${nw * 0.95},${y0 - 6 * k}`;
      if (kind === 'pearls' || kind === 'beads' || kind === 'lei') {
        const n = kind === 'choker' ? 8 : 15;
        for (let i = 0; i <= n; i++) { const t = i / n, x = -nw * 0.95 + 2 * nw * 0.95 * t, yy = (y0 - 6 * k) * (1 - t) * (1 - t) * 2 * 0 + (y0 - 6 * k) + (depth) * 2 * t * (1 - t) * 1; s += `<circle cx="${x.toFixed(1)}" cy="${yy.toFixed(1)}" r="${(kind === 'lei' ? 4.8 : 3.2) * k}" fill="${kind === 'lei' ? ['#f08fb0', '#ffd54a', '#fff', '#ff7f6e'][i % 4] : (i % 2 && kind === 'beads' ? a.col2 || K.lt(c) : c)}" stroke="${K.F.ink}" stroke-width="${Math.max(0.5, K.F.sw * 0.2)}"/>`; }
      } else s += `<path d="${d}" fill="none" stroke="${c}" stroke-width="${Math.max(1.6, 2.2 * k)}" stroke-linecap="round"/>`;
      if (kind === 'pendant') s += `<path d="M0,${y0 + depth * 0.5 - 2 * k} l${-5 * k},${8 * k} l${5 * k},${8 * k} l${5 * k},${-8 * k}z" ${K.st(a.col2 || '#2f6fd6', 0.5)}/>`;
      if (kind === 'medal') s += `<path d="M${-nw * 0.9},${y0 - 6 * k} L0,${y0 + 40 * k} L${nw * 0.9},${y0 - 6 * k}" fill="none" stroke="${a.col2 || '#d32f2f'}" stroke-width="${5 * k}"/><circle cx="0" cy="${y0 + 52 * k}" r="${10 * k}" ${K.st('#d4af37', 0.7)}/>`;
      if (kind === 'dogtags') s += `<rect x="${-8 * k}" y="${y0 + 36 * k}" width="${16 * k}" height="${22 * k}" rx="${6 * k}" ${K.st('#c4c8cf', 0.6)}/>`;
      if (kind === 'cross') s += `<path d="M0,${y0 + 36 * k} v${22 * k} M${-8 * k},${y0 + 43 * k} h${16 * k}" stroke="#d4af37" stroke-width="${3.4 * k}" stroke-linecap="round"/>`;
      return { front: s };
    }
    if (kind === 'lanyard') { s += `<path d="M${-nw},${y0 - 4 * k} L0,${y0 + 56 * k} L${nw},${y0 - 4 * k}" fill="none" stroke="${c}" stroke-width="${4.4 * k}" stroke-linejoin="round"/><rect x="${-11 * k}" y="${y0 + 54 * k}" width="${22 * k}" height="${30 * k}" rx="${3 * k}" ${K.st('#f5f5f2', 0.7)}/><rect x="${-6 * k}" y="${y0 + 58 * k}" width="${12 * k}" height="${10 * k}" fill="#9fd8f0"/>`; return { front: s }; }
    if (kind === 'stethoscope') { s += `<path d="M${-nw * 0.9},${y0 - 6 * k} Q${-nw * 1.1},${y0 + 50 * k} 0,${y0 + 66 * k} Q${nw * 1.1},${y0 + 50 * k} ${nw * 0.9},${y0 - 6 * k}" fill="none" stroke="${K.F.ink}" stroke-width="${5 * k}" stroke-linecap="round"/><circle cx="${nw * 0.3}" cy="${y0 + 74 * k}" r="${8 * k}" ${K.st('#c4c8cf', 0.8)}/>`; return { front: s }; }
    if (kind === 'headphoneneck') { s += `<path d="M${-nw * 1.7},${y0 + 4 * k} Q0,${y0 + 40 * k} ${nw * 1.7},${y0 + 4 * k}" fill="none" stroke="${c}" stroke-width="${6 * k}" stroke-linecap="round"/>` + [-1, 1].map((sg) => `<rect x="${sg * nw * 1.75 - 9 * k}" y="${y0 - 14 * k}" width="${18 * k}" height="${30 * k}" rx="${8 * k}" ${K.st(K.dk(c))}/>`).join(''); return { front: s }; }
    if (kind === 'camera') { s += `<path d="M${-nw},${y0 - 4 * k} L${-nw * 0.5},${y0 + 60 * k} M${nw},${y0 - 4 * k} L${nw * 0.5},${y0 + 60 * k}" stroke="${K.F.ink}" stroke-width="${3.6 * k}"/><rect x="${-24 * k}" y="${y0 + 56 * k}" width="${48 * k}" height="${32 * k}" rx="${5 * k}" ${K.st('#363a42')}/><circle cx="0" cy="${y0 + 72 * k}" r="${10 * k}" ${K.st('#14141a', 0.7)}/>`; return { front: s }; }
    if (kind === 'whistle') { s += `<path d="M${-nw},${y0 - 4 * k} Q0,${y0 + 50 * k} ${nw},${y0 - 4 * k}" fill="none" stroke="${K.F.ink}" stroke-width="${2 * k}"/><rect x="${-9 * k}" y="${y0 + 36 * k}" width="${18 * k}" height="${10 * k}" rx="${4 * k}" ${K.st('#c4c8cf', 0.6)}/>`; return { front: s }; }
    return null;
  };
}
function NK(id, aka, kind, col, o) { def(id, 'neck', { cat: 'neckwear', aka, col, pat: ['scarf', 'infinity', 'tie', 'skinnytie', 'bowtie', 'bandananeck', 'cravat', 'shawl'].includes(kind), draw: neckDraw(kind, o) }); }
NK('scarf', L(['scarf', 'winter scarf', 'long scarf', 'wool scarf', 'muffler']), 'scarf', ['#c8302a']);
NK('infinityscarf', L(['infinity scarf', 'snood', 'loop scarf', 'cowl scarf']), 'infinity', ['#8a94e8']);
NK('neckbandana', L(['neckerchief', 'neck bandana', 'cowboy bandana', 'scout scarf']), 'bandananeck', ['#c8302a']);
NK('ruff', L(['ruff', 'elizabethan collar', 'clown collar', 'frilly collar']), 'ruff', ['#f5f5f2']);
NK('shawl', L(['shawl', 'wrap', 'stole', 'pashmina']), 'shawl', ['#b08aa8']);
NK('tie', L(['tie', 'necktie', 'business tie', 'work tie', 'long tie']), 'tie', ['#b02a37']);
NK('skinnytie', L(['skinny tie', 'thin tie', 'slim tie']), 'skinnytie', ['#1c1c20']);
NK('bowtie', L(['bow tie', 'bowtie', 'dickie bow']), 'bowtie', ['#b02a37']);
NK('bolotie', L(['bolo tie', 'western tie']), 'bolo', ['#a8703a']);
NK('cravat', L(['cravat', 'ascot', 'silk scarf neck']), 'cravat', ['#d9a21b']);
NK('chain', L(['necklace', 'chain', 'gold chain', 'silver chain', 'chain necklace']), 'chain', ['#d4af37']);
NK('pendant', L(['pendant', 'pendant necklace', 'locket', 'gem necklace']), 'pendant', ['#d4af37']);
NK('pearlnecklace', L(['pearls', 'pearl necklace', 'string of pearls']), 'pearls', ['#f5f5f2']);
NK('choker', L(['choker', 'collar necklace', 'velvet choker']), 'choker', ['#1c1c20']);
NK('beadsnecklace', L(['beads', 'bead necklace', 'beaded necklace', 'tribal necklace', 'coral beads']), 'beads', ['#d63aa0']);
NK('lei', L(['lei', 'flower lei', 'hawaiian lei', 'flower garland']), 'lei', ['#f08fb0']);
NK('medal', L(['medal', 'gold medal', 'winner medal', 'olympic medal']), 'medal', ['#d4af37']);
NK('dogtags', L(['dog tags', 'dogtags', 'military tags']), 'dogtags', ['#c4c8cf']);
NK('crossnecklace', L(['cross necklace', 'crucifix', 'cross pendant']), 'cross', ['#d4af37']);
NK('lanyard', L(['lanyard', 'id badge', 'staff badge', 'name badge', 'press pass', 'badge lanyard']), 'lanyard', ['#2f6fd6']);
NK('stethoscope', L(['stethoscope', 'doctor stethoscope']), 'stethoscope', ['#1c1c20']);
NK('neckphones', L(['headphones around neck', 'headphones on neck', 'neck headphones']), 'headphoneneck', ['#1c1c20']);
NK('neckcamera', L(['camera around neck', 'tourist camera', 'photographer camera', 'neck camera']), 'camera', ['#363a42']);
NK('whistle', L(['whistle', 'coach whistle', 'referee whistle']), 'whistle', ['#c4c8cf']);

// ------------------------------------------------------------------ BAGS, BACK PIECES, WAIST, TAILS
function backDraw(kind, o = {}) {
  return (K, a) => {
    const B = K.B, k = K.k, Y = B.Y, c = a.col, back = a.view === 'back';
    const sw = B.X.sh + 8 * k, y0 = Y.sh, yh = Y.hip;
    const fill = K.cloth(c, a.pat, a.col2);
    let bk = '', fr = '';
    if (kind === 'backpack' || kind === 'schoolbag' || kind === 'hiker') {
      const w = (kind === 'hiker' ? 0.78 : 0.7) * sw, top = y0 - (kind === 'hiker' ? 26 : 8) * k, bot = yh + (kind === 'hiker' ? 28 : 6) * k;
      const body = `M${-w},${top + 14 * k} Q${-w},${top} ${-w + 14 * k},${top} H${w - 14 * k} Q${w},${top} ${w},${top + 14 * k} V${bot - 10 * k} Q${w},${bot} ${w - 12 * k},${bot} H${-w + 12 * k} Q${-w},${bot} ${-w},${bot - 10 * k}Z`;
      const draw = `<path d="${body}" ${K.st(fill)}/><path d="M${-w * 0.7},${top + (bot - top) * 0.55} H${w * 0.7} V${bot - 14 * k} H${-w * 0.7}Z" ${K.st(K.dk(c), 0.7)}/><path d="M${-w * 0.7},${top + (bot - top) * 0.55} H${w * 0.7}" ${K.ln(0.5)}/>` + (kind === 'hiker' ? `<rect x="${-w * 0.8}" y="${bot - 4 * k}" width="${w * 1.6}" height="${14 * k}" rx="${6 * k}" ${K.st('#5a6b3a')}/>` : '');
      if (back) return { back: '', mid: '', front: draw };
      bk = draw;
      fr = `<path d="M${-sw * 0.46},${y0 - 2 * k} Q${-sw * 0.55},${y0 + 46 * k} ${-sw * 0.5},${yh - 20 * k}" fill="none" stroke="${K.dk(c)}" stroke-width="${7 * k}" stroke-linecap="round"/><path d="M${sw * 0.46},${y0 - 2 * k} Q${sw * 0.55},${y0 + 46 * k} ${sw * 0.5},${yh - 20 * k}" fill="none" stroke="${K.dk(c)}" stroke-width="${7 * k}" stroke-linecap="round"/>`;
      return { back: bk, front: fr };
    }
    if (kind === 'cape') {
      const hem = o.hem ? hemY(B, o.hem) : hemY(B, 'shin'), w1 = sw + 30 * k;
      const d = `M${-sw * 0.7},${y0 - 4 * k} L${sw * 0.7},${y0 - 4 * k} Q${w1 * 1.3},${(y0 + hem) / 2} ${w1 * 1.1},${hem} Q0,${hem + 14 * k} ${-w1 * 1.1},${hem} Q${-w1 * 1.3},${(y0 + hem) / 2} ${-sw * 0.7},${y0 - 4 * k}Z`;
      const inner = a.col2 || K.dk(c, 0.7);
      const front = back ? `<path d="${d}" ${K.st(fill)}/>${K.shadeOver(d)}` : '';
      fr = !back ? `<path d="M${-sw * 0.62},${y0 - 2 * k} Q${-sw * 0.9},${y0 + 8 * k} ${-sw * 0.8},${y0 + 24 * k} M${sw * 0.62},${y0 - 2 * k} Q${sw * 0.9},${y0 + 8 * k} ${sw * 0.8},${y0 + 24 * k}" fill="none" stroke="${K.F.ink}" stroke-width="${K.F.sw}"/><circle cx="${-sw * 0.62}" cy="${y0 - 1 * k}" r="${5 * k}" ${K.st('#d4af37', 0.7)}/><circle cx="${sw * 0.62}" cy="${y0 - 1 * k}" r="${5 * k}" ${K.st('#d4af37', 0.7)}/>` : '';
      return { back: back ? '' : `<path d="${d}" ${K.st(inner)}/><path d="${d}" fill="${fill === c ? c : fill}" opacity=".4"/>`, front: front || fr, mid: '' };
    }
    if (kind === 'wings') {
      const sp = o.span || 2.3, h = (o.h || 150) * k;
      const wing = (sg) => {
        if (o.kind === 'bat') return `<path d="M${sg * sw * 0.5},${y0 + 10 * k} Q${sg * sw * 1.6},${y0 - h * 0.9} ${sg * sw * sp},${y0 - h * 0.5} Q${sg * sw * 1.9},${y0 - h * 0.1} ${sg * sw * 1.9},${y0 + h * 0.3} Q${sg * sw * 1.5},${y0 + h * 0.05} ${sg * sw * 1.3},${y0 + h * 0.4} Q${sg * sw * 1.0},${y0 + h * 0.1} ${sg * sw * 0.8},${y0 + h * 0.5}Z`;
        if (o.kind === 'butterfly' || o.kind === 'fairy') return `<path d="M${sg * sw * 0.4},${y0 + 20 * k} Q${sg * sw * 2.0},${y0 - h * 1.1} ${sg * sw * 2.1},${y0 - h * 0.2} Q${sg * sw * 1.8},${y0 + h * 0.2} ${sg * sw * 0.4},${y0 + 40 * k}Z M${sg * sw * 0.4},${y0 + 50 * k} Q${sg * sw * 1.6},${y0 + h * 0.2} ${sg * sw * 1.3},${y0 + h * 0.9} Q${sg * sw * 0.7},${y0 + h * 0.8} ${sg * sw * 0.4},${y0 + 60 * k}Z`;
        return `<path d="M${sg * sw * 0.45},${y0 + 8 * k} Q${sg * sw * 1.3},${y0 - h * 1.1} ${sg * sw * sp},${y0 - h * 0.7} Q${sg * sw * 2.0},${y0 - h * 0.45} ${sg * sw * 1.95},${y0 - h * 0.2} Q${sg * sw * 1.6},${y0 - h * 0.15} ${sg * sw * 1.55},${y0 + h * 0.05} Q${sg * sw * 1.2},${y0 + h * 0.1} ${sg * sw * 1.05},${y0 + h * 0.3} Q${sg * sw * 0.7},${y0 + h * 0.2} ${sg * sw * 0.45},${y0 + h * 0.35}Z`;
      };
      const d = wing(-1) + wing(1);
      return { back: `<path d="${d}" ${K.st(fill)}/>${o.kind === 'angel' || !o.kind ? `<path d="${wing(-1)}" fill="none" stroke="#fff" stroke-width="${2 * k}" opacity=".5" transform="translate(0,${8 * k})"/>` : ''}` };
    }
    if (kind === 'tail') {
      const yy = yh - 6 * k, ww = 14 * k;
      const d = o.kind === 'devil' ? `M0,${yy} Q${sw * 1.1},${yy + 30 * k} ${sw * 0.9},${yy + 100 * k} l${14 * k},${-4 * k} l${-6 * k},${22 * k} l${-14 * k},${-14 * k} Q${sw * 0.7},${yy + 40 * k} 0,${yy + 8 * k}Z` : `M0,${yy} Q${sw * 1.4},${yy - 10 * k} ${sw * 1.3},${yy + 80 * k} Q${sw * 1.1},${yy + 110 * k} ${sw * 0.8},${yy + 60 * k} Q${sw * 0.8},${yy + 20 * k} 0,${yy + ww}Z`;
      return { back: `<path d="${d}" ${K.st(fill)}/>` };
    }
    if (kind === 'quiver' || kind === 'swordback' || kind === 'guitar') {
      const sg = 1;
      if (kind === 'swordback') return { back: `<path d="M${-sw * 0.7},${y0 + 90 * k} L${sw * 0.9},${y0 - 90 * k}" stroke="#c4c8cf" stroke-width="${9 * k}" stroke-linecap="round"/><path d="M${-sw * 0.7},${y0 + 90 * k} L${-sw * 0.78},${y0 + 104 * k}" stroke="#6b4423" stroke-width="${12 * k}" stroke-linecap="round"/>`, front: `<path d="M${-sw * 0.5},${y0 + 6 * k} L${sw * 0.5},${yh - 20 * k}" stroke="#6b4423" stroke-width="${5 * k}"/>` };
      if (kind === 'quiver') return { back: `<path d="M${sw * 0.35},${y0 + 60 * k} L${sw * 0.9},${y0 - 70 * k} l${14 * k},${5 * k} L${sw * 0.62},${y0 + 70 * k}Z" ${K.st('#6b4423')}/><path d="M${sw * 0.85},${y0 - 74 * k} l${3 * k},${-24 * k} M${sw * 0.95},${y0 - 70 * k} l${6 * k},${-24 * k}" stroke="#d32f2f" stroke-width="${3 * k}"/>`, front: `<path d="M${-sw * 0.5},${y0 + 6 * k} L${sw * 0.5},${yh - 20 * k}" stroke="#6b4423" stroke-width="${5 * k}"/>` };
      return { back: `<ellipse cx="${sw * 0.2}" cy="${y0 + 70 * k}" rx="${sw * 0.55}" ry="${sw * 0.7}" ${K.st(fill)}/><rect x="${sw * 0.12}" y="${y0 - 90 * k}" width="${12 * k}" height="${150 * k}" ${K.st('#6b4423')}/>`, front: `<path d="M${-sw * 0.5},${y0 + 6 * k} L${sw * 0.5},${yh - 20 * k}" stroke="#6b4423" stroke-width="${5 * k}"/>` };
    }
    if (kind === 'jetpack' || kind === 'scuba') {
      const tank = (x) => `<rect x="${x - 14 * k}" y="${y0 - 14 * k}" width="${28 * k}" height="${(kind === 'jetpack' ? 90 : 110) * k}" rx="${12 * k}" ${K.st(kind === 'jetpack' ? fill : '#7cc4ee')}/>` + (kind === 'jetpack' ? `<path d="M${x - 8 * k},${y0 + 76 * k} L${x},${y0 + 110 * k} L${x + 8 * k},${y0 + 76 * k}Z" fill="#ff9d42"/>` : '');
      return { back: tank(-sw * 0.5) + tank(sw * 0.5) };
    }
    if (kind === 'shell') return { back: `<ellipse cx="0" cy="${(y0 + yh) / 2}" rx="${sw * 1.05}" ry="${(yh - y0) * 0.62}" ${K.st(fill)}/><path d="M${-sw * 0.5},${y0 + 24 * k} L${sw * 0.5},${y0 + 24 * k} M${0},${y0 + 4 * k} V${yh - 10 * k} M${-sw * 0.7},${y0 + 70 * k} H${sw * 0.7}" ${K.ln(0.8)}/>` };
    return null;
  };
}
function BG(id, aka, kind, col, o) { def(id, kind === 'cape' || kind === 'wings' || kind === 'tail' || kind === 'jetpack' || kind === 'scuba' || kind === 'shell' || kind === 'quiver' || kind === 'swordback' || kind === 'guitar' ? 'back' : 'bag', { cat: 'bag', aka, col, pat: ['cape', 'wings', 'tail', 'backpack'].includes(kind), draw: backDraw(kind, o) }); }
BG('backpack', L(['backpack', 'rucksack', 'bookbag', 'knapsack', 'daypack', 'laptop bag']), 'backpack', ['#d32f2f']);
BG('schoolbag', L(['school bag', 'school backpack', 'student bag']), 'schoolbag', ['#1b2a5a']);
BG('hikingpack', L(['hiking backpack', 'hiking pack', 'camping backpack', 'trekking bag', 'big backpack', 'travel backpack']), 'hiker', ['#5a6b3a']);
BG('cape', L(['cape', 'superhero cape', 'cloak', 'royal cape', 'vampire cape', 'hero cape']), 'cape', ['#d32f2f']);
BG('longcape', L(['long cape', 'long cloak', 'king cape']), 'cape', ['#7a1a2a'], { hem: 'floor' });
BG('angelwings', L(['angel wings', 'wings', 'white wings', 'feather wings']), 'wings', ['#f5f5f2'], { kind: 'angel' });
BG('batwings', L(['bat wings', 'demon wings', 'dragon wings', 'vampire wings']), 'wings', ['#363a42'], { kind: 'bat', span: 2.6 });
BG('fairywings', L(['fairy wings', 'butterfly wings', 'pixie wings']), 'wings', ['#b9a4e6'], { kind: 'fairy' });
BG('devilTail', L(['devil tail', 'demon tail', 'imp tail']), 'tail', ['#d32f2f'], { kind: 'devil' });
BG('foxtail', L(['tail', 'fox tail', 'cat tail', 'wolf tail', 'animal tail', 'cosplay tail']), 'tail', ['#f28a1d']);
BG('quiver', L(['quiver', 'arrows', 'archer quiver']), 'quiver', ['#6b4423']);
BG('swordonback', L(['sword on back', 'sword back', 'sheathed sword', 'katana on back']), 'swordback', ['#c4c8cf']);
BG('guitaronback', L(['guitar on back', 'guitar back', 'ukulele on back']), 'guitar', ['#a8703a']);
BG('jetpack', L(['jetpack', 'jet pack', 'rocket pack']), 'jetpack', ['#c4c8cf']);
BG('scubatank', L(['scuba tank', 'diving tank', 'oxygen tank', 'air tank']), 'scuba', ['#7cc4ee']);
BG('turtleshell', L(['shell', 'turtle shell', 'ninja turtle shell']), 'shell', ['#5a6b3a']);

// ---- bags carried on the body (hang at the hip / across the chest)
function carryDraw(kind) {
  return (K, a) => {
    const B = K.B, k = K.k, Y = B.Y, c = a.col, sw = B.X.sh, back = a.view === 'back';
    const fill = K.cloth(c, a.pat, a.col2);
    const side = kind === 'handbag' || kind === 'tote' || kind === 'briefcase' || kind === 'duffel' ? sw + 20 * k : sw;
    let s = '';
    const hy = Y.hip - 4 * k;
    if (kind === 'messenger' || kind === 'crossbody' || kind === 'satchel') {
      s += `<path d="M${-sw * 0.7},${Y.sh - 2 * k} L${sw * 0.8},${Y.hip - 10 * k}" stroke="${K.dk(c)}" stroke-width="${6 * k}" stroke-linecap="round"/>`;
      s += `<rect x="${sw * 0.35}" y="${Y.hip - 30 * k}" width="${50 * k}" height="${(kind === 'crossbody' ? 36 : 46) * k}" rx="${6 * k}" ${K.st(fill)}/><path d="M${sw * 0.35},${Y.hip - 30 * k} H${sw * 0.35 + 50 * k} L${sw * 0.35 + 25 * k},${Y.hip - 8 * k}Z" ${K.st(K.dk(c), 0.7)}/>`;
      return { front: back ? '' : s };
    }
    if (kind === 'fanny') { const y = hemY(B, 'waist'); s += `<rect x="${-sw * 0.9}" y="${y - 5 * k}" width="${sw * 1.8}" height="${9 * k}" fill="${K.dk(c)}"/><rect x="${-22 * k}" y="${y - 12 * k}" width="${44 * k}" height="${26 * k}" rx="${8 * k}" ${K.st(fill)}/><path d="M${-22 * k},${y} H${22 * k}" ${K.ln(0.5)}/>`; return { front: back ? '' : s }; }
    if (kind === 'handbag' || kind === 'tote' || kind === 'briefcase' || kind === 'duffel') {
      const x = side + 4 * k, w = (kind === 'tote' ? 54 : kind === 'duffel' ? 66 : 48) * k, h = (kind === 'tote' ? 56 : kind === 'duffel' ? 38 : 40) * k;
      s += `<path d="M${x - w * 0.3},${hy - h - 16 * k} Q${x},${hy - h - 34 * k} ${x + w * 0.3},${hy - h - 16 * k}" fill="none" stroke="${K.dk(c)}" stroke-width="${4 * k}"/>`;
      s += `<path d="M${x - w / 2},${hy - h} H${x + w / 2} L${x + w * 0.44},${hy} H${x - w * 0.44}Z" ${K.st(fill)}/>${K.shadeOver(`M${x - w / 2},${hy - h} H${x + w / 2} L${x + w * 0.44},${hy} H${x - w * 0.44}Z`)}`;
      if (kind === 'briefcase') s += `<rect x="${x - 4 * k}" y="${hy - h - 6 * k}" width="${8 * k}" height="${6 * k}" ${K.st('#d4af37', 0.5)}/><path d="M${x - w / 2},${hy - h * 0.45} H${x + w / 2}" ${K.ln(0.5)}/>`;
      return { front: back ? '' : s };
    }
    return null;
  };
}
function CB(id, aka, kind, col) { def(id, 'bag', { cat: 'bag', aka, col, pat: kind !== 'briefcase', draw: carryDraw(kind) }); }
CB('messenger', L(['messenger bag', 'shoulder bag', 'satchel', 'sling bag', 'courier bag', 'postman bag']), 'messenger', ['#6b4423']);
CB('crossbody', L(['crossbody bag', 'cross body bag', 'small bag', 'purse strap']), 'crossbody', ['#c2307e']);
CB('fannypack', L(['fanny pack', 'waist bag', 'belt bag', 'bum bag', 'hip bag']), 'fanny', ['#1c1c20']);
CB('handbag', L(['handbag', 'purse', 'ladies bag', 'designer bag']), 'handbag', ['#c8302a']);
CB('totebag', L(['tote bag', 'tote', 'shopping bag', 'grocery bag', 'canvas bag']), 'tote', ['#e8d08a']);
CB('briefcase', L(['briefcase', 'suitcase', 'attache case', 'business bag', 'work bag', 'portfolio case']), 'briefcase', ['#4a2c1a']);
CB('duffelbag', L(['duffel bag', 'gym bag', 'sports bag', 'holdall', 'travel bag']), 'duffel', ['#1b2a5a']);

// ---- waist pieces
function waistDraw(kind) {
  return (K, a) => {
    const B = K.B, k = K.k, c = a.col, y = hemY(B, 'waist'), w = halfW(B, y, 3 * k);
    let s = '';
    if (kind === 'belt') s = `<rect x="${-w}" y="${y - 5 * k}" width="${w * 2}" height="${10 * k}" ${K.st(c, 0.8)}/><rect x="${-8 * k}" y="${y - 7 * k}" width="${16 * k}" height="${14 * k}" rx="2" ${K.st(a.col2 || '#d4af37', 0.6)}/>`;
    else if (kind === 'toolbelt') s = `<rect x="${-w}" y="${y - 6 * k}" width="${w * 2}" height="${12 * k}" ${K.st(c, 0.8)}/>` + [-0.7, -0.25, 0.3, 0.75].map((t, i) => `<rect x="${t * w - 9 * k}" y="${y + 4 * k}" width="${18 * k}" height="${(22 + (i % 2) * 10) * k}" rx="${3 * k}" ${K.st(K.dk(c), 0.6)}/>`).join('') + `<path d="M${w * 0.5},${y + 6 * k} l${10 * k},${30 * k}" stroke="#c4c8cf" stroke-width="${5 * k}"/>`;
    else if (kind === 'sash') s = `<path d="M${-w},${y - 8 * k} H${w} V${y + 12 * k} H${-w}Z" ${K.st(c)}/><path d="M${w * 0.3},${y + 12 * k} l${-6 * k},${50 * k} h${14 * k} l${6 * k},${-50 * k}z" ${K.st(K.dk(c))}/>`;
    else if (kind === 'obi') s = `<rect x="${-w}" y="${y - 22 * k}" width="${w * 2}" height="${44 * k}" ${K.st(c)}/><path d="M${-w},${y} H${w}" ${K.ln(0.4)} opacity=".5"/><path d="M${w * 0.1},${y - 18 * k} l${w * 0.6},${-10 * k} v${50 * k} l${-w * 0.6},${-6 * k}z" ${K.st(K.dk(c))}/>`;
    else if (kind === 'holster') s = `<rect x="${-w}" y="${y - 5 * k}" width="${w * 2}" height="${10 * k}" ${K.st('#3a2a1c', 0.8)}/><path d="M${w * 0.7},${y + 2 * k} q${14 * k},${4 * k} ${10 * k},${46 * k} l${-20 * k},${-2 * k}z" ${K.st('#4a2c1a', 0.7)}/><path d="M${w * 0.78},${y + 4 * k} v${-12 * k}" stroke="#222" stroke-width="${5 * k}"/>`;
    else if (kind === 'cummerbund') s = `<path d="M${-w},${y - 14 * k} H${w} V${y + 14 * k} H${-w}Z" ${K.st(c)}/>` + [-2, -1, 0, 1, 2].map((i) => `<path d="M${-w},${y + i * 5 * k} H${w}" ${K.ln(0.3)} opacity=".5"/>`).join('');
    else if (kind === 'suspenders') { s = [-1, 1].map((sg) => `<path d="M${sg * w * 0.5},${B.Y.sh - 2 * k} V${y + 8 * k}" stroke="${c}" stroke-width="${8 * k}"/>`).join('') + `<rect x="${-w}" y="${y - 3 * k}" width="${w * 2}" height="${5 * k}" fill="${K.dk(c)}"/>`; }
    else if (kind === 'tutuwrap') s = `<path d="M${-w * 1.9},${y + 24 * k} Q0,${y - 12 * k} ${w * 1.9},${y + 24 * k} Q0,${y + 40 * k} ${-w * 1.9},${y + 24 * k}Z" ${K.st(c)}/>`;
    else if (kind === 'apron') s = `<path d="M${-w * 0.8},${y} H${w * 0.8} L${w * 1.05},${y + 90 * k} H${-w * 1.05}Z" ${K.st(c)}/><path d="M${-w},${y - 4 * k} H${w}" ${K.ln(0.8)}/>`;
    else if (kind === 'kiltsporran') s = `<ellipse cx="0" cy="${y + 26 * k}" rx="${15 * k}" ry="${14 * k}" ${K.st('#6b4423')}/><rect x="${-w}" y="${y - 5 * k}" width="${w * 2}" height="${9 * k}" ${K.st('#3a2a1c', 0.7)}/>`;
    return { mid: a.view === 'back' && kind === 'apron' ? '' : s };
  };
}
function WS(id, aka, kind, col) { def(id, 'waist', { cat: 'waist', aka, col, pat: false, draw: waistDraw(kind) }); }
WS('belt', L(['belt', 'leather belt', 'waist belt', 'black belt', 'champion belt']), 'belt', ['#3a2a1c']);
WS('toolbelt', L(['tool belt', 'utility belt', 'carpenter belt', 'builder belt', 'batman belt', 'ammo belt']), 'toolbelt', ['#6b4423']);
WS('sash', L(['sash', 'waist sash', 'ribbon sash', 'cloth belt']), 'sash', ['#d32f2f']);
WS('obi', L(['obi', 'kimono belt', 'wide belt', 'corset belt']), 'obi', ['#d4af37']);
WS('holster', L(['holster', 'gun belt', 'cowboy belt', 'gunslinger belt', 'sheriff belt']), 'holster', ['#4a2c1a']);
WS('cummerbund', L(['cummerbund', 'tuxedo sash', 'waist wrap']), 'cummerbund', ['#7a1a2a']);
WS('suspenders', L(['suspenders', 'braces', 'trouser braces']), 'suspenders', ['#d32f2f']);
WS('waistapron', L(['waist apron', 'half apron', 'waiter apron', 'bistro apron', 'server apron']), 'apron', ['#1c1c20']);
WS('sporran', L(['sporran', 'scottish pouch']), 'kiltsporran', ['#6b4423']);

// ------------------------------------------------------------------ FOOTWEAR
// The built-in styles draw their own feet (they step with the legs), so shoes colour and reshape those (hint s = the stickman's shoe);
// an uploaded character has no built-in feet, so its shoes are drawn over its feet.
function shoeDraw(kind) {
  return (K, a) => {
    const B = K.B;
    if (!B.custom) return null;
    const k = K.k, c = a.col, lx = B.legs.x, w = B.foot.w, y = 880;
    const hgt = { boot: 54, tall: 80, high: 30, flat: 16, heel: 26, sandal: 10, skate: 30, flipper: 8 }[kind] || 18;
    let s = '';
    for (const sg of [-1, 1]) {
      const x = sg * lx;
      s += `<path d="M${x - w * 0.5},${y - hgt * k} H${x + w * 0.5} V${y - 6 * k} Q${x + w * 0.72},${y - 4 * k} ${x + w * 0.7},${y} H${x - w * 0.55} Q${x - w * 0.58},${y - 6 * k} ${x - w * 0.5},${y - hgt * k}Z" ${K.st(K.cloth(c, a.pat, a.col2), 0.8)}/><path d="M${x - w * 0.55},${y - 5 * k} H${x + w * 0.7}" stroke="#f5f5f2" stroke-width="${4 * k}"/>`;
    }
    return { front: s };
  };
}
function SH(id, aka, kind, col, nat) { def(id, 'feet', { cat: 'shoes', aka, col, pat: false, nat: nat || {}, draw: shoeDraw(kind) }); }
SH('sneakers', L(['sneakers', 'trainers', 'running shoes', 'athletic shoes', 'gym shoes', 'tennis shoes', 'kicks']), 'flat', ['#f5f5f2'], { s: 'sneakers' });
SH('hightops', L(['high tops', 'high-tops', 'hightops', 'basketball shoes', 'converse', 'chucks', 'high top sneakers']), 'high', ['#d32f2f'], { s: 'hightops' });
SH('boots', L(['boots', 'ankle boots', 'work boots', 'combat boots', 'army boots', 'leather boots', 'hiking boots', 'timberlands', 'chelsea boots']), 'boot', ['#4a2c1a'], { s: 'boots' });
SH('cowboyboots', L(['cowboy boots', 'western boots', 'riding boots']), 'tall', ['#a8703a'], { s: 'boots' });
SH('rainboots', L(['rain boots', 'wellies', 'wellingtons', 'gumboots', 'galoshes', 'rubber boots']), 'tall', ['#f7c52b'], { s: 'boots' });
SH('kneeboots', L(['knee boots', 'thigh high boots', 'tall boots', 'go-go boots']), 'tall', ['#1c1c20'], { s: 'boots' });
SH('loafers', L(['loafers', 'dress shoes', 'oxfords', 'brogues', 'formal shoes', 'office shoes', 'leather shoes', 'school shoes', 'moccasins']), 'flat', ['#2a1a10'], { s: 'slipons' });
SH('heels', L(['heels', 'high heels', 'pumps', 'stilettos', 'court shoes', 'platform heels', 'wedges']), 'heel', ['#c2307e'], { s: 'slipons' });
SH('flats', L(['flats', 'ballet flats', 'ballerina flats', 'slip ons', 'slip-ons', 'plimsolls', 'pumps flat']), 'flat', ['#f08fb0'], { s: 'slipons' });
SH('sandals', L(['sandals', 'flip flops', 'flip-flops', 'slides', 'slippers', 'house slippers', 'crocs', 'clogs', 'thongs']), 'sandal', ['#a8703a'], { s: 'slipons' });
SH('cleats', L(['cleats', 'football boots', 'soccer cleats', 'studs shoes', 'spikes', 'track spikes']), 'flat', ['#39ff88'], { s: 'sneakers' });
SH('skates', L(['roller skates', 'ice skates', 'skates', 'rollerblades', 'inline skates', 'skateboard shoes']), 'skate', ['#f5f5f2'], { s: 'hightops' });
SH('flippers', L(['flippers', 'swim fins', 'diving fins']), 'flipper', ['#2f6fd6'], { s: 'slipons' });
SH('ballethoes', L(['ballet shoes', 'pointe shoes', 'dance shoes']), 'flat', ['#f3b8c4'], { s: 'slipons' });
SH('skiboots', L(['ski boots', 'snow boots', 'moon boots', 'winter boots']), 'boot', ['#d32f2f'], { s: 'boots' });
SH('barefoot', L(['barefoot', 'no shoes', 'bare feet', 'shoeless']), 'sandal', ['#d8a478'], { s: 'slipons' });

export const SLOT_OF = (id) => (GARMENTS.get(id) || {}).slot || '';
